<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BattleonForgett | Home - Competitive Gaming Platform</title>
    <style>
        body {
            font-family: 'Oxanium', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #0f0f1a;
            color: #e0e0e0;
        }
        .top-bar {
            background: linear-gradient(90deg, #1a1a2e 0%, #16213e 100%);
            padding: 8px 0;
            border-bottom: 1px solid #2a2a4a;
        }
        .server-status {
            display: flex;
            align-items: center;
            font-size: 14px;
        }
        .status-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            margin-right: 8px;
        }
        .online {
            background-color: #4ade80;
            box-shadow: 0 0 8px #4ade80;
        }
        .top-links {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 20px;
        }
        .download-btn {
            background: linear-gradient(90deg, #6d28d9 0%, #4c1d95 100%);
            color: white;
            padding: 6px 12px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s;
        }
        .download-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(109, 40, 217, 0.4);
        }
        .social-links {
            display: flex;
            gap: 12px;
        }
        .social-links a {
            color: #a1a1aa;
            font-size: 16px;
            transition: all 0.3s;
        }
        .social-links a:hover {
            color: #6d28d9;
            transform: translateY(-2px);
        }
        .main-header {
            padding: 20px 0;
            background-color: rgba(15, 15, 26, 0.9);
            backdrop-filter: blur(8px);
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        .logo-img {
            height: 40px;
        }
        .navbar-nav {
            gap: 20px;
        }
        .nav-link {
            color: #e0e0e0 !important;
            font-weight: 600;
            position: relative;
            padding: 8px 0 !important;
        }
        .nav-link:hover {
            color: #6d28d9 !important;
        }
        .nav-link:after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: 0;
            left: 0;
            background-color: #6d28d9;
            transition: width 0.3s;
        }
        .nav-link:hover:after {
            width: 100%;
        }
        .dropdown-menu {
            background-color: #1a1a2e;
            border: 1px solid #2a2a4a;
        }
        .dropdown-item {
            color: #e0e0e0;
        }
        .dropdown-item:hover {
            background-color: #6d28d9;
            color: white;
        }
        @media (max-width: 992px) {
            .navbar-nav {
                padding-top: 20px;
            }
            .nav-link {
                padding: 10px 0 !important;
            }
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Oxanium:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<?php include 'header.php'?>


<!-- News Page: BattleonForgett -->
<section style="background: url('19.jpg') no-repeat center center/cover; padding: 80px 20px; color: #ffffff; font-family: 'Segoe UI', sans-serif;">

  <!-- Header -->
  <div style="max-width: 1200px; margin: auto; text-align: center; margin-bottom: 60px;">
    <h1 style="font-size: 40px; color: #00ffcc; margin-bottom: 10px;">BattleonForgett News & Updates</h1>
    <p style="font-size: 18px; color: #e0e0e0;">Stay ahead with the latest dev logs, seasonal updates, PvP changes, and community highlights from the world of BattleonForgett.</p>
  </div>

  <!-- Featured Update -->
  <div style="max-width: 1200px; margin: auto; background-color: rgba(20, 20, 30, 0.9); border-radius: 12px; padding: 30px; display: flex; flex-wrap: wrap; align-items: center; gap: 30px; margin-bottom: 60px;">
    <div style="flex: 1 1 500px;">
      <img src="3.jpg" alt="Major Update" style="width: 100%; border-radius: 10px; box-shadow: 0 0 20px rgba(0, 255, 191, 0.3);">
    </div>
    <div style="flex: 1 1 500px;">
      <h2 style="color: #84ff1b; font-size: 28px; margin-bottom: 10px;">⛩️ Rift Expansion: Era of the Forgotten</h2>
      <p style="font-size: 17px; line-height: 1.7; text-align: justify;">
        The long-awaited expansion is here! Explore the fractured islands of the Forgotten Realm where ancient lore and new enemies await. New questlines, factions, and time-altered weapons have been introduced to alter the course of PvE and PvP alike. Don't miss the Season Pass—available now!
      </p>
    </div>
  </div>

  <!-- News Grid -->
  <div style="max-width: 1200px; margin: auto; display: flex; flex-wrap: wrap; gap: 30px;">

    <!-- News Item -->
    <div style="flex: 1 1 280px; background-color: rgba(30, 30, 50, 0.9); padding: 20px; border-radius: 10px;">
      <img src="4.jpg" alt="PvP Update" style="width: 100%; border-radius: 8px; margin-bottom: 12px;">
      <h3 style="font-size: 20px; color: #ffcc00;">⚔️ PvP Balance Patch</h3>
      <p style="font-size: 15px; line-height: 1.6;">New arenas, class tweaks, and real-time duel rankings have been added. Arena Season 4 starts this weekend—gear up!</p>
    </div>

    <!-- News Item -->
    <div style="flex: 1 1 280px; background-color: rgba(30, 30, 50, 0.9); padding: 20px; border-radius: 10px;">
      <img src="5.jpg" alt="Developer Log" style="width: 100%; border-radius: 8px; margin-bottom: 12px;">
      <h3 style="font-size: 20px; color: #7ee2ff;">🛠 Dev Log: Underworld Update</h3>
      <p style="font-size: 15px; line-height: 1.6;">The dev team reveals behind-the-scenes work on dynamic weather, boss logic, and modular raid maps. Sneak peek inside!</p>
    </div>

    <!-- News Item -->
    <div style="flex: 1 1 280px; background-color: rgba(30, 30, 50, 0.9); padding: 20px; border-radius: 10px;">
      <img src="6.jpg" alt="Lore Reveal" style="width: 100%; border-radius: 8px; margin-bottom: 12px;">
      <h3 style="font-size: 20px; color: #cddc39;">📜 Lore Reveal: Rise of the Dissonants</h3>
      <p style="font-size: 15px; line-height: 1.6;">Uncover the forgotten history of the Rift Lords and their betrayal. The Codex has been updated with new entries and prophecy scrolls.</p>
    </div>

    <!-- News Item -->
    <div style="flex: 1 1 280px; background-color: rgba(30, 30, 50, 0.9); padding: 20px; border-radius: 10px;">
      <img src="20.jpg" alt="Community Highlight" style="width: 100%; border-radius: 8px; margin-bottom: 12px;">
      <h3 style="font-size: 20px; color: #ff99cc;">🎨 Community Highlights</h3>
      <p style="font-size: 15px; line-height: 1.6;">From fanart to cosplay and speedruns, the BattleonForgett community is on fire! Check out the top 10 creations of the month.</p>
    </div>
  </div>

  <!-- Call to Action -->
  <div style="max-width: 1200px; margin: 80px auto 0; text-align: center;">
    <h2 style="font-size: 26px; color: #ffffff; margin-bottom: 10px;">📩 Want Exclusive Updates?</h2>
    <p style="font-size: 16px; color: #cccccc;">Subscribe to our dev letter and get insider news before anyone else.</p>
    <a href="#" style="display: inline-block; background-color: #00ffcc; color: #000000; padding: 12px 24px; border-radius: 30px; text-decoration: none; font-weight: bold; margin-top: 20px;">Subscribe Now</a>
  </div>
</section>




<?php include 'footer.php'?>


    <a id="scroll-top"></a>

    <!-- Javascript -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery.easing.js"></script>

    <script src="assets/js/plugin.js"></script>
    <script src="assets/js/count-down.js"></script>
    <script src="assets/js/shortcodes.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>