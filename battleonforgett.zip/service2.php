<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BattleonForgett | Home - Competitive Gaming Platform</title>
    <style>
        body {
            font-family: 'Oxanium', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #0f0f1a;
            color: #e0e0e0;
        }
        .top-bar {
            background: linear-gradient(90deg, #1a1a2e 0%, #16213e 100%);
            padding: 8px 0;
            border-bottom: 1px solid #2a2a4a;
        }
        .server-status {
            display: flex;
            align-items: center;
            font-size: 14px;
        }
        .status-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            margin-right: 8px;
        }
        .online {
            background-color: #4ade80;
            box-shadow: 0 0 8px #4ade80;
        }
        .top-links {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 20px;
        }
        .download-btn {
            background: linear-gradient(90deg, #6d28d9 0%, #4c1d95 100%);
            color: white;
            padding: 6px 12px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s;
        }
        .download-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(109, 40, 217, 0.4);
        }
        .social-links {
            display: flex;
            gap: 12px;
        }
        .social-links a {
            color: #a1a1aa;
            font-size: 16px;
            transition: all 0.3s;
        }
        .social-links a:hover {
            color: #6d28d9;
            transform: translateY(-2px);
        }
        .main-header {
            padding: 20px 0;
            background-color: rgba(15, 15, 26, 0.9);
            backdrop-filter: blur(8px);
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        .logo-img {
            height: 40px;
        }
        .navbar-nav {
            gap: 20px;
        }
        .nav-link {
            color: #e0e0e0 !important;
            font-weight: 600;
            position: relative;
            padding: 8px 0 !important;
        }
        .nav-link:hover {
            color: #6d28d9 !important;
        }
        .nav-link:after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: 0;
            left: 0;
            background-color: #6d28d9;
            transition: width 0.3s;
        }
        .nav-link:hover:after {
            width: 100%;
        }
        .dropdown-menu {
            background-color: #1a1a2e;
            border: 1px solid #2a2a4a;
        }
        .dropdown-item {
            color: #e0e0e0;
        }
        .dropdown-item:hover {
            background-color: #6d28d9;
            color: white;
        }
        @media (max-width: 992px) {
            .navbar-nav {
                padding-top: 20px;
            }
            .nav-link {
                padding: 10px 0 !important;
            }
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Oxanium:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<?php include 'header.php'?>

<!-- Fullscreen Background + Tournament Hero Section -->
<div style="font-family: 'Orbitron', sans-serif; background: url('18.jpg') no-repeat center center/cover; color: #fff; padding: 140px 20px 80px; text-align: center; position: relative;">
  <div style="background: rgba(0, 0, 0, 0.75); padding: 60px 30px; border-radius: 15px; max-width: 950px; margin: auto;">
    <h1 style="font-size: 60px; margin-bottom: 20px; text-transform: uppercase; color: #ff4500; text-shadow: 0 0 15px #ff4500;">BattleonForgett Tournaments</h1>
    <p style="font-size: 22px; max-width: 750px; margin: 0 auto 30px; line-height: 1.6;">
      Join the realm of elite gamers where every battle tests your reflexes, strategy, and willpower. Dominate arenas, lead your guild, and rise through the ranks in our legendary tournaments!
    </p>
    <a href="#tournament-list" style="background: #ff4500; color: #fff; padding: 16px 40px; font-size: 18px; border-radius: 10px; text-decoration: none; box-shadow: 0 6px 16px rgba(255, 69, 0, 0.7); font-weight: bold;">
      Browse Tournaments
    </a>
  </div>
</div>

<!-- Tournament Modes Section -->
<div id="tournament-list" style="background-color: #0f0f0f; padding: 80px 20px; color: #e0e0e0;">
  <h2 style="text-align: center; font-size: 38px; color: #ff6347; margin-bottom: 50px;">Tournament Modes</h2>
  <div style="display: flex; flex-wrap: wrap; gap: 35px; justify-content: center;">

    <!-- Solo Champion -->
    <div style="background: #1c1c1c; border-radius: 14px; padding: 35px; width: 340px; box-shadow: 0 0 20px rgba(255, 99, 71, 0.5);">
      <h3 style="color: #ff6347; font-size: 24px;">Solo Champion Battles</h3>
      <p style="font-size: 16px; margin-top: 15px;">1v1 and FFA matches where only the fiercest survive.</p>
      <ul style="padding-left: 20px; margin-top: 15px; font-size: 15px;">
        <li>Weekly eliminations</li>
        <li>Exclusive leaderboard rewards</li>
        <li>Live-streamed with shoutcasters</li>
      </ul>
    </div>

    <!-- Guild Wars -->
    <div style="background: #1c1c1c; border-radius: 14px; padding: 35px; width: 340px; box-shadow: 0 0 20px rgba(255, 99, 71, 0.5);">
      <h3 style="color: #ff6347; font-size: 24px;">Guild Wars</h3>
      <p style="font-size: 16px; margin-top: 15px;">Join guild battles for control, prestige, and rare loot.</p>
      <ul style="padding-left: 20px; margin-top: 15px; font-size: 15px;">
        <li>Monthly battles</li>
        <li>Territory domination</li>
        <li>Guild-only quests</li>
      </ul>
    </div>

    <!-- Seasonal Mega -->
    <div style="background: #1c1c1c; border-radius: 14px; padding: 35px; width: 340px; box-shadow: 0 0 20px rgba(255, 99, 71, 0.5);">
      <h3 style="color: #ff6347; font-size: 24px;">Seasonal Mega Tournaments</h3>
      <p style="font-size: 16px; margin-top: 15px;">Massive seasonal events with global reach and epic prizes.</p>
      <ul style="padding-left: 20px; margin-top: 15px; font-size: 15px;">
        <li>Quarterly world qualifiers</li>
        <li>Legendary loot & titles</li>
        <li>Broadcasted highlights</li>
      </ul>
    </div>

  </div>
</div>

<!-- How to Join Section -->
<div style="background-color: #161616; padding: 70px 30px;">
  <h2 style="text-align: center; font-size: 34px; color: #ff4500; margin-bottom: 30px;">How to Join the Fight</h2>
  <ol style="max-width: 700px; margin: auto; font-size: 17px; line-height: 1.8; color: #ccc;">
    <li><strong>Login</strong> to your BattleonForgett account.</li>
    <li><strong>Head to the Events tab</strong> and select your desired tournament.</li>
    <li><strong>Gear up</strong> and customize your character.</li>
    <li><strong>Compete</strong> on scheduled dates and earn your place.</li>
    <li><strong>Track performance</strong> through real-time stats and brackets.</li>
    <li><strong>Win rewards</strong> and rise in fame!</li>
  </ol>
</div>

<!-- Rewards Section -->
<div style="background: #0e0e0e; color: #fff; padding: 80px 20px;">
  <h2 style="text-align: center; font-size: 36px; color: #ff4500; margin-bottom: 40px;">Unlock Exclusive Rewards</h2>
  <p style="text-align: center; max-width: 700px; margin: 0 auto 40px; font-size: 16px; color: #bbb;">
    Beyond bragging rights—BattleonForgett tournaments bring you elite loot and recognition.
  </p>
  <ul style="max-width: 700px; margin: auto; padding-left: 25px; font-size: 16px; line-height: 1.6; color: #ccc;">
    <li><strong>Legendary Skins:</strong> Visual prestige for top warriors.</li>
    <li><strong>Premium Currencies:</strong> Gems, gold, and crafting resources.</li>
    <li><strong>Rare Items:</strong> Armor, weapons, and accessories.</li>
    <li><strong>Leaderboard Fame:</strong> Make your mark on the global ladder.</li>
    <li><strong>IRL Merch:</strong> Hoodies, gaming mice, and more!</li>
  </ul>
</div>

<!-- Upcoming Tournaments Grid -->
<div style="background-color: #1a1a1a; padding: 70px 20px;">
  <h2 style="text-align: center; font-size: 34px; color: #ff4500; margin-bottom: 50px;">Upcoming Events</h2>
  <div style="display: flex; flex-wrap: wrap; gap: 30px; justify-content: center;">

    <!-- Event Cards -->
    <div style="background: #222; padding: 25px; border-radius: 12px; width: 320px; color: #eee; box-shadow: 0 0 12px #ff4500;">
      <h3 style="font-size: 24px;">Solo Champion Cup</h3>
      <p><strong>Date:</strong> June 15 – June 20</p>
      <p><strong>Entry:</strong> Free</p>
      <p style="font-size: 14px;">Compete in 1v1 arena duels and prove your skill.</p>
    </div>

    <div style="background: #222; padding: 25px; border-radius: 12px; width: 320px; color: #eee; box-shadow: 0 0 12px #ff4500;">
      <h3 style="font-size: 24px;">Guild Wars Clash</h3>
      <p><strong>Date:</strong> July 10 – July 20</p>
      <p><strong>Entry:</strong> 50 Gems / Guild</p>
      <p style="font-size: 14px;">Fight for guild supremacy in this month-long skirmish.</p>
    </div>

    <div style="background: #222; padding: 25px; border-radius: 12px; width: 320px; color: #eee; box-shadow: 0 0 12px #ff4500;">
      <h3 style="font-size: 24px;">Seasonal Mega Clash</h3>
      <p><strong>Date:</strong> August 5 – August 15</p>
      <p><strong>Entry:</strong> 100 Gems</p>
      <p style="font-size: 14px;">The grand showdown with global fame and epic gear.</p>
    </div>
  </div>
</div>

<!-- Final CTA -->
<div style="background-color: #0c0c0c; text-align: center; padding: 60px 20px;">
  <a href="/register" style="background: linear-gradient(45deg, #ff4500, #ff6347); padding: 18px 50px; color: #fff; font-size: 20px; font-weight: bold; text-decoration: none; border-radius: 10px; box-shadow: 0 0 18px rgba(255, 69, 0, 0.7);">
    Register for Battle Glory Now
  </a>
</div>


<?php include 'footer.php'?>


    <a id="scroll-top"></a>

    <!-- Javascript -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery.easing.js"></script>

    <script src="assets/js/plugin.js"></script>
    <script src="assets/js/count-down.js"></script>
    <script src="assets/js/shortcodes.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>