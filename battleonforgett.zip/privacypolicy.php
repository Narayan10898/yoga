<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BattleonForgett | Home - Competitive Gaming Platform</title>
    <style>
        body {
            font-family: 'Oxanium', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #0f0f1a;
            color: #e0e0e0;
        }
        .top-bar {
            background: linear-gradient(90deg, #1a1a2e 0%, #16213e 100%);
            padding: 8px 0;
            border-bottom: 1px solid #2a2a4a;
        }
        .server-status {
            display: flex;
            align-items: center;
            font-size: 14px;
        }
        .status-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            margin-right: 8px;
        }
        .online {
            background-color: #4ade80;
            box-shadow: 0 0 8px #4ade80;
        }
        .top-links {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 20px;
        }
        .download-btn {
            background: linear-gradient(90deg, #6d28d9 0%, #4c1d95 100%);
            color: white;
            padding: 6px 12px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s;
        }
        .download-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(109, 40, 217, 0.4);
        }
        .social-links {
            display: flex;
            gap: 12px;
        }
        .social-links a {
            color: #a1a1aa;
            font-size: 16px;
            transition: all 0.3s;
        }
        .social-links a:hover {
            color: #6d28d9;
            transform: translateY(-2px);
        }
        .main-header {
            padding: 20px 0;
            background-color: rgba(15, 15, 26, 0.9);
            backdrop-filter: blur(8px);
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        .logo-img {
            height: 40px;
        }
        .navbar-nav {
            gap: 20px;
        }
        .nav-link {
            color: #e0e0e0 !important;
            font-weight: 600;
            position: relative;
            padding: 8px 0 !important;
        }
        .nav-link:hover {
            color: #6d28d9 !important;
        }
        .nav-link:after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: 0;
            left: 0;
            background-color: #6d28d9;
            transition: width 0.3s;
        }
        .nav-link:hover:after {
            width: 100%;
        }
        .dropdown-menu {
            background-color: #1a1a2e;
            border: 1px solid #2a2a4a;
        }
        .dropdown-item {
            color: #e0e0e0;
        }
        .dropdown-item:hover {
            background-color: #6d28d9;
            color: white;
        }
        @media (max-width: 992px) {
            .navbar-nav {
                padding-top: 20px;
            }
            .nav-link {
                padding: 10px 0 !important;
            }
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Oxanium:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<?php include 'header.php'?>



<!-- Privacy Policy Page: BattleonForgett -->
<section style="background: url('14.jpg') no-repeat center center/cover; padding: 80px 20px; font-family: 'Segoe UI', sans-serif; color: #fff;">

  <!-- Header -->
  <div style="max-width: 1000px; margin: auto; text-align: center; margin-bottom: 50px;">
    <h1 style="font-size: 42px; color: #00ffd0;">🔐 Privacy Policy</h1>
    <p style="font-size: 18px; color: #ccc;">Your data, our responsibility – Last Updated: May 21, 2025</p>
  </div>

  <!-- Content Container -->
  <div style="max-width: 1000px; margin: auto; background: rgba(25,25,35,0.95); padding: 40px; border-radius: 16px; line-height: 1.8;">

    <h2 style="color: #ff4081;">1. Introduction</h2>
    <p>Welcome to BattleonForgett, a gaming universe built for warriors, strategists, and adventurers. This Privacy Policy explains how we collect, use, and protect your personal information while you're using our website, game, or any related services.</p>

    <h2 style="color: #ff4081;">2. Information We Collect</h2>
    <ul style="padding-left: 20px;">
      <li><strong>Account Info:</strong> Username, email address, password (encrypted)</li>
      <li><strong>Gameplay Data:</strong> Player progress, achievements, inventory, guilds</li>
      <li><strong>Device Info:</strong> IP address, browser type, operating system, device ID</li>
      <li><strong>Payment Info:</strong> If you purchase in-game items (via secure third-party gateway)</li>
      <li><strong>Communication:</strong> Emails, support tickets, chat logs, forum posts</li>
    </ul>

    <h2 style="color: #ff4081;">3. How We Use Your Information</h2>
    <ul style="padding-left: 20px;">
      <li>To manage your game account and progression</li>
      <li>To improve game performance and balance</li>
      <li>To communicate updates, promotions, and news</li>
      <li>To prevent fraud, cheating, and abuse</li>
      <li>To comply with legal obligations</li>
    </ul>

    <h2 style="color: #ff4081;">4. Cookies & Tracking</h2>
    <p>We use cookies and similar technologies to enhance your user experience. Cookies help us remember your login session, track player activity for analytics, and personalize game content. You can disable cookies in your browser settings.</p>

    <h2 style="color: #ff4081;">5. Third-Party Services</h2>
    <p>We may use trusted partners for services like payments (Stripe, PayPal), analytics (Google Analytics), social media integration (Discord, Twitch), and cloud hosting. These services have their own privacy policies and data practices.</p>

    <h2 style="color: #ff4081;">6. Data Security</h2>
    <p>We use encryption, firewalls, two-factor authentication, and data access controls to protect your information. However, no method of transmission over the internet is 100% secure. You are responsible for safeguarding your password.</p>

    <h2 style="color: #ff4081;">7. Children's Privacy</h2>
    <p>BattleonForgett is not intended for children under 13. We do not knowingly collect personal information from minors. If you are a parent and believe your child has provided data to us, please contact us for deletion.</p>

    <h2 style="color: #ff4081;">8. Your Rights</h2>
    <ul style="padding-left: 20px;">
      <li>Access your personal data</li>
      <li>Request correction of inaccurate data</li>
      <li>Delete your account and data</li>
      <li>Withdraw consent for marketing</li>
    </ul>
    <p>To exercise your rights, email us at <strong>privacy@battleonforgett.com</strong>.</p>

    <h2 style="color: #ff4081;">9. Data Retention</h2>
    <p>We retain player data as long as your account remains active or as needed to provide you with services. Upon deletion request, we remove your information within 30 business days.</p>

    <h2 style="color: #ff4081;">10. Global Data Transfers</h2>
    <p>If you're located outside the United States, your data may be transferred to and processed in the US. We take appropriate safeguards to ensure your data is handled securely across borders.</p>

    <h2 style="color: #ff4081;">11. Changes to This Policy</h2>
    <p>We may update this Privacy Policy periodically. We will notify users via email or in-game message if major changes are made. You are encouraged to review this page regularly.</p>

    <h2 style="color: #ff4081;">12. Contact Us</h2>
    <p>If you have questions, concerns, or requests regarding your data or this policy, contact us:</p>
    <p>
      📧 Email: <strong>privacy@battleonforgett.com</strong><br>
      📍 Address: 123 DragonForge Road, Titan City, GA 30210<br>
      ☎️ Support Center: <a href="/contact.html" style="color:#00ffd0;">Contact Page</a>
    </p>

  </div>

  <!-- Final Note -->
  <div style="max-width: 1000px; margin: 60px auto 0; text-align: center;">
    <h2 style="color: #00ffd0; font-size: 26px;">🎮 Your Privacy, Your Power</h2>
    <p style="color: #ccc;">We believe privacy and transparency make the BattleonForgett experience stronger for everyone.</p>
  </div>

</section>



 <?php include 'footer.php'?>


    <a id="scroll-top"></a>

    <!-- Javascript -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery.easing.js"></script>

    <script src="assets/js/plugin.js"></script>
    <script src="assets/js/count-down.js"></script>
    <script src="assets/js/shortcodes.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>