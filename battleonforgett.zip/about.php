<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie" xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<!--<![endif]-->

<head>
    <!-- Basic Page Needs -->
    <meta charset="utf-8">
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <title>hulksprinkwhisker | About Us</title>

    <meta name="author" content="themesflat.com">

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- Theme Style -->
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">

    <!-- Reponsive -->
    <link rel="stylesheet" type="text/css" href="assets/css/responsive.css">

    <!-- Favicon and Touch Icons  -->
    <link rel="shortcut icon" href="assets/icon/Favicon.png">
    <link rel="apple-touch-icon-precomposed" href="assets/icon/Favicon.png">

</head>
<style>
  .about-us {
    padding: 50px 20px;
    background-color: #0e0e0e;
    color: #f0f0f0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  }

  .about-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 30px;
  }

  .about-img img {
    width: 100%;
    max-width: 400px;
    border-radius: 10px;
  }

  .about-text {
    max-width: 600px;
  }

  .about-text h2 {
    font-size: 2rem;
    margin-bottom: 15px;
    
  }

  .about-text p {
    margin-bottom: 15px;
    line-height: 1.6;
  }

  /* Responsive for larger screens */
  @media (min-width: 768px) {
    .about-content {
      flex-direction: row;
      justify-content: space-between;
      align-items: center;
    }

    .about-img, .about-text {
      flex: 1;
    }

    .about-text {
      padding-left: 40px;
    }
  }
</style>

<?php include 'header.php'?>

            <!-- page title -->
            <section class="fl-page-title">
                <div class="overlay"></div>
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="page-title-inner flex">
                                <div class="page-title-heading">
                                    <h2 class="heading">About Us</h2>
                                </div>
                                <div class="breadcrumbs">
                                    <ul>
                                        <li><a href="index.php">Home</a></li>
                                        <li>About Us</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

<section class="about-us">
  <div class="container">
        <u><h3 style="text-align:center;">About Us - hulksprinkwhisker</h3></u>
        <br>
    <div class="about-content">
      <div class="about-img">
        <img src="about1.jpg" alt="About hulksprinkwhisker">
      </div>
      <div class="about-text">
        <h2 style="color:red;">About hulksprinkwhisker</h2>
        <p style="font-size:18px; text-align:justify;">
          Welcome to <strong>hulksprinkwhisker</strong> — where elite gaming meets futuristic firepower. We're not just a platform; we're a battleground for passionate gamers who crave high-performance experiences, thrilling tournaments, and a forged brotherhood of digital warriors.
        </p>
        <p  style="font-size:18px; text-align:justify;">
          Whether you’re grinding for glory, raiding dungeons, or sniping your way to the top of the leaderboard, hulksprinkwhisker is your ultimate arena. Join our ever-evolving world of eSports, community-driven events, and epic loot drops
          This isn’t just a platform—it’s a digital forge, where raw skill is refined into legendary status. Join us to connect with fellow gamers, discover new worlds, and unleash your ultimate potential.
        </p>
      </div>
    </div>
    <div class="about-content">
      <div class="about-text">
        <h2  style="color:blue;">Your Compatiable gaming platform to enjoy</h2>
        <p  style="font-size:18px; text-align:justify;">
          At hulksprinkwhisker, we pride ourselves on being your most compatible gaming platform to enjoy, explore, and conquer. Whether you're a casual gamer diving into daily quests or a competitive warrior aiming for leaderboard domination, we’ve designed a space that adapts to your unique style. From lightning-fast servers to cross-platform accessibility and personalized gameplay experiences
        </p>
        <p  style="font-size:18px; text-align:justify;">
        our ecosystem empowers you to forge your path without limits. We believe that gaming should be seamless, social, and seriously fun—so we’ve built a platform where community, performance, and passion come together. Join hulksprinkwhisker and experience the future of gaming—where every player fits, every victory counts, and every session feels legendary        </p>
      </div>
      <div class="about-img">
        <img src="about2.jpg" alt="About hulksprinkwhisker">
      </div>
    </div>
    <div class="about-content">
      <div class="about-img">
        <img src="about3.jpg" alt="About hulksprinkwhisker">
      </div>
      <div class="about-text">
        <h2  style="color:green;">Unleashing Power, Passion, and Play</h2>
        <p style="font-size:18px; text-align:justify;">
          we're not just launching games — we're unleashing power, passion, and play into everything we do. Born from the relentless energy of true gamers, our platform is built to fuel adrenaline-pumping action, strategic showdowns, and immersive worlds where every click carries weight. Whether you're dominating PvP arenas, forging alliances in co-op raids, or chasing epic loot across universes.
        </p>
        <p style="font-size:18px; text-align:justify;">
        We believe that gaming isn’t just a hobby—it’s a mindset, a culture, and a battleground for innovation. Our goal is to empower players with high-performance tools, seamless access, and a bold community that thrives on challenge, collaboration, and chaos
        Whether you're a console champion, a PC strategist, or a mobile brawler, hulksprinkwhisker adapts to your battlefield. Our platform supports a wide range of genres, skill levels.</p>
      </div>
    </div>
  </div>
</section>


<section style="padding: 60px 20px; background-color: #121212; color: #fff; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">
        <u><h3 style="text-align:center; color:rgb(55, 212, 196);">Redefining the gaming experience in a different way</h3></u>
        <br>
        <br>
  <div style="max-width: 1200px; margin: auto;">
    
    <!-- Row 1 -->
    <div style="display: flex; flex-wrap: wrap; margin-bottom: 40px; gap: 20px;">
      <div style="flex: 1 1 calc(33.333% - 20px); background-color: #1e1e1e; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px rgba(255, 60, 0, 0.2);">
        <h3 style="color:rgb(41, 179, 28); margin-bottom: 10px; font-size:18px;">Next-Gen gaming </h3>
        <p style="font-size:18px; line-height: 1.6;">The latest consoles bring unparalleled speed and graphics with lightning-fast SSDs and ray tracing support, delivering hyper-realistic gameplay like never before.</p>
      </div>
      <div style="flex: 1 1 calc(33.333% - 20px); background-color: #1e1e1e; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px rgba(255, 60, 0, 0.2);">
        <h3 style="color:rgb(195, 34, 181); margin-bottom: 10px; font-size:18px;">4K Gaming Redefined</h3>
        <p style="font-size:18px; line-height: 1.6;">Enjoy ultra-crisp resolution and high frame rates with support for 4K HDR gaming across leading consoles like the PlayStation 5 and Xbox Series X.</p>
      </div>
      <div style="flex: 1 1 calc(33.333% - 20px); background-color: #1e1e1e; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px rgba(255, 60, 0, 0.2);">
        <h3 style="color:rgb(137, 229, 33); margin-bottom: 10px; font-size:18px;">Controller Evolution</h3>
        <p style="font-size:18px; line-height: 1.6;">Experience dynamic feedback with haptic triggers, adaptive vibration, and ergonomic builds that put next-level immersion right at your fingertips.</p>
      </div>
    </div>

    <!-- Row 2 -->
    <div style="display: flex; flex-wrap: wrap; gap: 20px;">
      <div style="flex: 1 1 calc(33.333% - 20px); background-color: #1e1e1e; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px rgba(255, 60, 0, 0.2);">
        <h3 style="color:rgb(207, 37, 114); margin-bottom: 10px; font-size:18px;">Cloud Gaming Ready</h3>
        <p style="font-size:18px; line-height: 1.6;">New consoles are optimized for cloud-based gameplay, giving you instant access to vast game libraries with minimal downloads and zero compromise on quality.</p>
      </div>
      <div style="flex: 1 1 calc(33.333% - 20px); background-color: #1e1e1e; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px rgba(255, 60, 0, 0.2);">
        <h3 style="color:rgba(198, 23, 38, 0.97); margin-bottom: 10px; font-size:18px;">Cross-Platform Connectivity</h3>
        <p style="font-size:18px; line-height: 1.6;">Game without borders—modern consoles now support cross-platform multiplayer so you can squad up with friends, no matter the device.</p>
      </div>
      <div style="flex: 1 1 calc(33.333% - 20px); background-color: #1e1e1e; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px rgba(255, 60, 0, 0.2);">
        <h3 style="color: #ff3c00; margin-bottom: 10px; font-size:18px;">Built for Streaming</h3>
        <p style="font-size:18px; line-height: 1.6;">With integrated streaming tools and social sharing features, new consoles let you broadcast your gameplay or highlights with just one click.</p>
      </div>
    </div>
  </div>
</section>

<section style="padding: 60px 20px; background-color: #0e0e0e; color: #fff; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">
        <u><h3 style="text-align:center;">Our Latest Gaming consoles 2025</h3></u>
        <br>
        <br>
  <div style="max-width: 1400px; margin: auto; display: flex; flex-wrap: wrap; gap: 20px; justify-content: center;">
    <!-- Explorer 1 -->
    <div style="flex: 1 1 calc(25% - 20px); background-color: #1c1c1c; padding: 20px; border-radius: 12px; text-align: center;">
      <img src="about4.jpg" alt="ShadowBlitz" style="width: 100%; max-width: 160px; border-radius: 50%; margin-bottom: 15px;">
      <h3 style="color:rgb(64, 22, 220); font-size: 18px;">ShadowBlitz Bloomer</h3>
      <p style="font-size:18px; line-height: 1.5;">Stealth master and map scout, ShadowBlitz explores the darkest corners of unreleased titles with precision and thrill.</p>
    </div>

    <!-- Explorer 2 -->
    <div style="flex: 1 1 calc(25% - 20px); background-color: #1c1c1c; padding: 20px; border-radius: 12px; text-align: center;">
      <img src="about5.jpg" alt="CrimsonNova" style="width: 100%; max-width: 160px; border-radius: 50%; margin-bottom: 15px;">
      <h3 style="color:rgb(205, 231, 40); font-size:18px;">CrimsonNova Jaxx</h3>
      <p style="font-size:18px; line-height: 1.5;">A fiery competitor, she tests advanced combat engines and multiplayer dynamics on every next-gen platform.</p>
    </div>

    <!-- Explorer 3 -->
    <div style="flex: 1 1 calc(25% - 20px); background-color: #1c1c1c; padding: 20px; border-radius: 12px; text-align: center;">
      <img src="about6.jpg" alt="TitanFrost" style="width: 100%; max-width: 160px; border-radius: 50%; margin-bottom: 15px;">
      <h3 style="color:rgb(211, 110, 16); font-size:18px;">TitanFrost Rimbova</h3>
      <p style="font-size:18px; line-height: 1.5;">TitanFrost tests open-world environments, measuring survival physics and deep resource systems.</p>
    </div>

    <!-- Explorer 4 -->
    <div style="flex: 1 1 calc(25% - 20px); background-color: #1c1c1c; padding: 20px; border-radius: 12px; text-align: center;">
      <img src="about7.jpg" alt="EchoPulse" style="width: 100%; max-width: 160px; border-radius: 50%; margin-bottom: 15px;">
      <h3 style="color:rgb(193, 56, 97); font-size:18px;">EchoPulse scaplus</h3>
      <p style="font-size:18px; line-height: 1.5;">An audio-reactive explorer, EchoPulse reviews rhythm-based titles and in-game sound design performance.</p>
    </div>

  </div>
</section>


            <!-- Footer -->
            <?php include 'footer.php'?>


    <a id="scroll-top"></a>

    <!-- Javascript -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery.easing.js"></script>

    <script src="assets/js/plugin.js"></script>
    <script src="assets/js/count-down.js"></script>
    <script src="assets/js/shortcodes.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>