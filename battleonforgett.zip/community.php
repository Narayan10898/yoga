<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BattleonForgett | Home - Competitive Gaming Platform</title>
    <style>
        body {
            font-family: 'Oxanium', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #0f0f1a;
            color: #e0e0e0;
        }
        .top-bar {
            background: linear-gradient(90deg, #1a1a2e 0%, #16213e 100%);
            padding: 8px 0;
            border-bottom: 1px solid #2a2a4a;
        }
        .server-status {
            display: flex;
            align-items: center;
            font-size: 14px;
        }
        .status-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            margin-right: 8px;
        }
        .online {
            background-color: #4ade80;
            box-shadow: 0 0 8px #4ade80;
        }
        .top-links {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 20px;
        }
        .download-btn {
            background: linear-gradient(90deg, #6d28d9 0%, #4c1d95 100%);
            color: white;
            padding: 6px 12px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s;
        }
        .download-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(109, 40, 217, 0.4);
        }
        .social-links {
            display: flex;
            gap: 12px;
        }
        .social-links a {
            color: #a1a1aa;
            font-size: 16px;
            transition: all 0.3s;
        }
        .social-links a:hover {
            color: #6d28d9;
            transform: translateY(-2px);
        }
        .main-header {
            padding: 20px 0;
            background-color: rgba(15, 15, 26, 0.9);
            backdrop-filter: blur(8px);
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        .logo-img {
            height: 40px;
        }
        .navbar-nav {
            gap: 20px;
        }
        .nav-link {
            color: #e0e0e0 !important;
            font-weight: 600;
            position: relative;
            padding: 8px 0 !important;
        }
        .nav-link:hover {
            color: #6d28d9 !important;
        }
        .nav-link:after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: 0;
            left: 0;
            background-color: #6d28d9;
            transition: width 0.3s;
        }
        .nav-link:hover:after {
            width: 100%;
        }
        .dropdown-menu {
            background-color: #1a1a2e;
            border: 1px solid #2a2a4a;
        }
        .dropdown-item {
            color: #e0e0e0;
        }
        .dropdown-item:hover {
            background-color: #6d28d9;
            color: white;
        }
        @media (max-width: 992px) {
            .navbar-nav {
                padding-top: 20px;
            }
            .nav-link {
                padding: 10px 0 !important;
            }
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Oxanium:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<?php include 'header.php'?>


<!-- Community Page: BattleonForgett -->
<section style="background: url('15.jpg') no-repeat center center/cover; padding: 80px 20px; font-family: 'Segoe UI', sans-serif; color: #ffffff;">

  <!-- Page Header -->
  <div style="max-width: 1200px; margin: auto; text-align: center; margin-bottom: 60px;">
    <h1 style="font-size: 42px; color: #00ffd0; margin-bottom: 10px;">BattleonForgett Community</h1>
    <p style="font-size: 18px; color: #d0d0d0;">Unite with warriors, artists, coders, streamers, and lorekeepers from across realms. Shape the legacy of BattleonForgett together!</p>
  </div>

  <!-- Hero Banner -->
  <div style="max-width: 1200px; margin: auto; background-color: rgba(25,25,35,0.9); border-radius: 12px; padding: 40px; margin-bottom: 60px;">
    <h2 style="font-size: 28px; color: #c6ff00; margin-bottom: 20px;">🎮 Your Voice. Your Stories. Your Game.</h2>
    <p style="font-size: 17px; line-height: 1.7;">
      The BattleonForgett community fuels our universe—through feedback, fan creations, tournaments, and shared adventures. Whether you're a casual player, PvP gladiator, guild master, or lore aficionado, this is your place to connect, create, and be celebrated.
    </p>
  </div>

  <!-- Community Highlights -->
  <div style="max-width: 1200px; margin: auto; display: flex; flex-wrap: wrap; gap: 30px;">

    <!-- Fan Art -->
    <div style="flex: 1 1 300px; background-color: rgba(35,35,50,0.95); padding: 20px; border-radius: 10px;">
      <img src="14.jpg" alt="Fan Art" style="width: 100%; border-radius: 10px; margin-bottom: 15px;">
      <h3 style="color: #ff80ab; font-size: 20px;">🎨 Fan Art Gallery</h3>
      <p style="font-size: 15px; line-height: 1.6;">Explore jaw-dropping artwork submitted by our talented community. From class concepts to legendary battles, view or upload your masterpiece!</p>
    </div>

    <!-- Cosplay -->
    <div style="flex: 1 1 300px; background-color: rgba(35,35,50,0.95); padding: 20px; border-radius: 10px;">
      <img src="13.jpg" alt="Cosplay" style="width: 100%; border-radius: 10px; margin-bottom: 15px;">
      <h3 style="color: #ffd740; font-size: 20px;">🧝 Cosplay Chronicles</h3>
      <p style="font-size: 15px; line-height: 1.6;">From RiftKnight armor to ShadowLords, see epic cosplay from conventions and online events. Submit yours and be featured!</p>
    </div>

    <!-- Forum Threads -->
    <div style="flex: 1 1 300px; background-color: rgba(35,35,50,0.95); padding: 20px; border-radius: 10px;">
      <img src="12.jpg" alt="Forum" style="width: 100%; border-radius: 10px; margin-bottom: 15px;">
      <h3 style="color: #80d8ff; font-size: 20px;">📣 Forum Discussions</h3>
      <p style="font-size: 15px; line-height: 1.6;">Join our official forums and shape the world with your ideas. Share bug reports, build guides, event tips, and story theories.</p>
    </div>

    <!-- Stream & Content Creators -->
    <div style="flex: 1 1 300px; background-color: rgba(35,35,50,0.95); padding: 20px; border-radius: 10px;">
      <img src="11.jpg" alt="Streamers" style="width: 100%; border-radius: 10px; margin-bottom: 15px;">
      <h3 style="color: #69f0ae; font-size: 20px;">🎥 Streamers & YouTubers</h3>
      <p style="font-size: 15px; line-height: 1.6;">Watch top creators go head-to-head in Rift PvP or dive into lore analysis. Want to be featured? Join our creator program!</p>
    </div>
  </div>

  <!-- Upcoming Community Events -->
  <div style="max-width: 1200px; margin: 80px auto 40px;">
    <h2 style="font-size: 26px; color: #ffffff; text-align: center; margin-bottom: 30px;">📅 Upcoming Events</h2>
    <div style="display: flex; flex-wrap: wrap; gap: 30px; justify-content: center;">

      <div style="background-color: rgba(50,50,70,0.95); padding: 20px; border-radius: 10px; width: 280px;">
        <h3 style="font-size: 18px; color: #ff5252;">🔥 RiftRaid Speedrun Contest</h3>
        <p style="font-size: 14px;">Date: June 14, 2025</p>
        <p style="font-size: 14px;">Prize Pool: $1000 + in-game rewards</p>
      </div>

      <div style="background-color: rgba(50,50,70,0.95); padding: 20px; border-radius: 10px; width: 280px;">
        <h3 style="font-size: 18px; color: #00e5ff;">📸 Screenshot Showcase</h3>
        <p style="font-size: 14px;">Submit your best action screenshot. Winners will be spotlighted on our homepage!</p>
      </div>

      <div style="background-color: rgba(50,50,70,0.95); padding: 20px; border-radius: 10px; width: 280px;">
        <h3 style="font-size: 18px; color: #ffd740;">🎁 Anniversary Trivia Night</h3>
        <p style="font-size: 14px;">Date: July 8, 2025 – Live on Discord & Twitch</p>
      </div>
    </div>
  </div>

  <!-- Join Us CTA -->
  <div style="text-align: center; margin-top: 60px;">
    <h2 style="font-size: 26px; color: #ffffff;">🚀 Become Part of BattleonForgett</h2>
    <p style="font-size: 16px; color: #cccccc;">Register for forums, join Discord, and submit your fan works today!</p>
    <a href="#" style="display: inline-block; background-color: #00ffd0; color: #000; padding: 14px 28px; font-weight: bold; border-radius: 30px; text-decoration: none; margin-top: 20px;">Join the Community</a>
  </div>

</section>





<?php include 'footer.php'?>


    <a id="scroll-top"></a>

    <!-- Javascript -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery.easing.js"></script>

    <script src="assets/js/plugin.js"></script>
    <script src="assets/js/count-down.js"></script>
    <script src="assets/js/shortcodes.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>