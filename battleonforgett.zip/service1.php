<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BattleonForgett | Home - Competitive Gaming Platform</title>
    <style>
        body {
            font-family: 'Oxanium', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #0f0f1a;
            color: #e0e0e0;
        }
        .top-bar {
            background: linear-gradient(90deg, #1a1a2e 0%, #16213e 100%);
            padding: 8px 0;
            border-bottom: 1px solid #2a2a4a;
        }
        .server-status {
            display: flex;
            align-items: center;
            font-size: 14px;
        }
        .status-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            margin-right: 8px;
        }
        .online {
            background-color: #4ade80;
            box-shadow: 0 0 8px #4ade80;
        }
        .top-links {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 20px;
        }
        .download-btn {
            background: linear-gradient(90deg, #6d28d9 0%, #4c1d95 100%);
            color: white;
            padding: 6px 12px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s;
        }
        .download-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(109, 40, 217, 0.4);
        }
        .social-links {
            display: flex;
            gap: 12px;
        }
        .social-links a {
            color: #a1a1aa;
            font-size: 16px;
            transition: all 0.3s;
        }
        .social-links a:hover {
            color: #6d28d9;
            transform: translateY(-2px);
        }
        .main-header {
            padding: 20px 0;
            background-color: rgba(15, 15, 26, 0.9);
            backdrop-filter: blur(8px);
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        .logo-img {
            height: 40px;
        }
        .navbar-nav {
            gap: 20px;
        }
        .nav-link {
            color: #e0e0e0 !important;
            font-weight: 600;
            position: relative;
            padding: 8px 0 !important;
        }
        .nav-link:hover {
            color: #6d28d9 !important;
        }
        .nav-link:after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: 0;
            left: 0;
            background-color: #6d28d9;
            transition: width 0.3s;
        }
        .nav-link:hover:after {
            width: 100%;
        }
        .dropdown-menu {
            background-color: #1a1a2e;
            border: 1px solid #2a2a4a;
        }
        .dropdown-item {
            color: #e0e0e0;
        }
        .dropdown-item:hover {
            background-color: #6d28d9;
            color: white;
        }
        @media (max-width: 992px) {
            .navbar-nav {
                padding-top: 20px;
            }
            .nav-link {
                padding: 10px 0 !important;
            }
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Oxanium:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<?php include 'header.php'?>


<!-- BattleonForgett Game Showcase Section with Background Image -->
<section style="background: url('17.jpg') center center / cover no-repeat, linear-gradient(135deg, #0a0a12, #1b1b2f); padding: 100px 20px; color: #e0e0e0; font-family: 'Orbitron', sans-serif; position: relative; z-index: 1;">

  <!-- Optional dark overlay for readability -->
  <div style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(10, 10, 18, 0.8); z-index: -1;"></div>

  <div style="max-width: 1300px; margin: auto; display: flex; flex-wrap: wrap; gap: 50px; align-items: center;">
    <!-- Game Image -->
    <div style="flex: 1 1 520px; text-align: center;">
      <img src="16.jpg" alt="BattleonForgett Key Art" style="width: 100%; max-width: 540px; border-radius: 16px; box-shadow: 0 0 40px rgba(0, 255, 128, 0.3);">
      <p style="margin-top: 14px; font-size: 16px; color: #00ff99;">In-Game Cinematic Still</p>
    </div>

    <!-- Game Intro -->
    <div style="flex: 1 1 650px;">
      <h2 style="font-size: 32px; color: #76ff03; margin-bottom: 20px;">BattleonForgett: Rise of the Shattered Legion</h2>
      <p style="font-size: 18px; line-height: 1.8; text-align: justify;">
        <strong>BattleonForgett</strong> is a next-gen multiplayer combat RPG set in a world consumed by eternal war. Wield forgotten relics, forge alliances, and lead your faction through treacherous wastelands, flying citadels, and ancient rift portals. Each battle you fight rewrites history in a world where memories are currency and death resets the timeline.
      </p>
      <p style="font-size: 17px; line-height: 1.8; text-align: justify; color: #bbbbbb;">
        Join dynamic events, conquer zone-based maps, and unlock legacy weapons as you uncover the secrets of The Forgett—a realm haunted by fractured lore and corrupted champions.
      </p>
    </div>
  </div>

  <!-- Core Features -->
  <div style="max-width: 1300px; margin: 80px auto 0;">
    <h3 style="text-align: center; font-size: 26px; color: #ffffff; margin-bottom: 40px;">🔥 BattleonForgett Core Features</h3>
    <div style="display: flex; flex-wrap: wrap; gap: 30px; justify-content: space-between;">

      <div style="flex: 1 1 22%; background: #222233; padding: 22px; border-radius: 12px;">
        <h4 style="color: #00e5ff;">⚔️ Legacy Weapon System</h4>
        <p style="font-size: 16px; line-height: 1.7; text-align: justify;">
          Discover and upgrade relic weapons that remember your past victories—and failures.
        </p>
      </div>

      <div style="flex: 1 1 22%; background: #222233; padding: 22px; border-radius: 12px;">
        <h4 style="color: #ffca28;">🧠 Memory-Based Progression</h4>
        <p style="font-size: 16px; line-height: 1.7; text-align: justify;">
          Progress through narrative-driven quests where memories alter player stats and outcomes.
        </p>
      </div>

      <div style="flex: 1 1 22%; background: #222233; padding: 22px; border-radius: 12px;">
        <h4 style="color: #7c4dff;">🌌 Zone Control PvP</h4>
        <p style="font-size: 16px; line-height: 1.7; text-align: justify;">
          Engage in faction-based warfare across evolving zones with real-time map domination.
        </p>
      </div>

      <div style="flex: 1 1 22%; background: #222233; padding: 22px; border-radius: 12px;">
        <h4 style="color: #ff3d00;">🚀 Riftportals & Time Events</h4>
        <p style="font-size: 16px; line-height: 1.7; text-align: justify;">
          Enter weekly rift dungeons—time-sensitive challenges with global impact and rare loot.
        </p>
      </div>
    </div>
  </div>

  <!-- Deep Game Lore -->
  <div style="max-width: 1300px; margin: 80px auto;">
    <h3 style="color: #64ffda;">📚 Game Lore</h3>
    <p style="font-size: 17px; line-height: 1.8; text-align: justify;">
      In a fractured timeline created by the Fall of the Orbital Citadel, the world of Forgett was split into shards. Each region now lives a different history, ruled by memory-hungry warlords and forgotten gods. You are a Riftwalker—a champion born from failed realities. Travel across collapsed dimensions, piece together universal truths, and choose whether to save or shatter what remains.
    </p>
  </div>

  <!-- Game Modes -->
  <div style="max-width: 1300px; margin: 60px auto;">
    <h3 style="color: #ffa726;">🎮 Game Modes</h3>
    <ul style="font-size: 16px; line-height: 1.8; padding-left: 20px;">
      <li><strong>Campaign Chronicles:</strong> Solo or Co-op story episodes spanning multiple realities.</li>
      <li><strong>Rift Arena PvP:</strong> 8v8 tactical deathmatches with time-modified arenas.</li>
      <li><strong>Warlord Trials:</strong> Weekly boss raid events with global leaderboard tracking.</li>
      <li><strong>Guild Siege:</strong> Build your guild fortress and engage in scheduled large-scale territory wars.</li>
    </ul>
  </div>

  <!-- Characters Spotlight -->
  <div style="max-width: 1300px; margin: 60px auto;">
    <h3 style="color: #80d8ff;">🧙 Key Characters</h3>
    <ul style="font-size: 16px; line-height: 1.8; padding-left: 20px;">
      <li><strong>Varyn the Recalled:</strong> Time mage who commands anomalies to undo fate.</li>
      <li><strong>Serana Wyrnshade:</strong> Exiled queen turned vengeful Riftlord with soul-forged blades.</li>
      <li><strong>OMNI-38:</strong> AI construct searching for its creator to stabilize reality.</li>
      <li><strong>Krosh The Breached:</strong> A riftspawned behemoth sealed under the Shatter Peaks.</li>
    </ul>
  </div>

  <!-- Requirements -->
  <div style="max-width: 1300px; margin: 60px auto 0;">
    <h3 style="color: #ef5350;">🖥 System Requirements</h3>
    <table style="width: 100%; border-collapse: collapse; color: #ffffff; margin-top: 20px;">
      <tr style="background-color: #1f1f2d;">
        <th style="text-align: left; padding: 12px;">Component</th>
        <th style="text-align: left; padding: 12px;">Minimum</th>
        <th style="text-align: left; padding: 12px;">Recommended</th>
      </tr>
      <tr>
        <td style="padding: 12px;">OS</td>
        <td style="padding: 12px;">Windows 10 (64-bit)</td>
        <td style="padding: 12px;">Windows 11 (64-bit)</td>
      </tr>
      <tr style="background-color: #1f1f2d;">
        <td style="padding: 12px;">Processor</td>
        <td style="padding: 12px;">Intel i5 / Ryzen 5</td>
        <td style="padding: 12px;">Intel i7 / Ryzen 7</td>
      </tr>
      <tr>
        <td style="padding: 12px;">RAM</td>
        <td style="padding: 12px;">8 GB</td>
        <td style="padding: 12px;">16 GB</td>
      </tr>
      <tr style="background-color: #1f1f2d;">
        <td style="padding: 12px;">GPU</td>
        <td style="padding: 12px;">GTX 1060 / RX 580</td>
        <td style="padding: 12px;">RTX 3060 / RX 6700 XT</td>
      </tr>
      <tr>
        <td style="padding: 12px;">Storage</td>
        <td style="padding: 12px;">50 GB HDD</td>
        <td style="padding: 12px;">50 GB SSD</td>
      </tr>
    </table>
  </div>
</section>



  <?php include 'footer.php'?>

    <!-- Javascript -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery.easing.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/swiper-bundle.min.js"></script>
    <script src="assets/js/swiper.js"></script>

    <script src="assets/js/plugin.js"></script>
    <script src="assets/js/count-down.js"></script>
    <script src="assets/js/shortcodes.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>