<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BattleonForgett | Home - Competitive Gaming Platform</title>
    <style>
        body {
            font-family: 'Oxanium', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #0f0f1a;
            color: #e0e0e0;
        }
        .top-bar {
            background: linear-gradient(90deg, #1a1a2e 0%, #16213e 100%);
            padding: 8px 0;
            border-bottom: 1px solid #2a2a4a;
        }
        .server-status {
            display: flex;
            align-items: center;
            font-size: 14px;
        }
        .status-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            margin-right: 8px;
        }
        .online {
            background-color: #4ade80;
            box-shadow: 0 0 8px #4ade80;
        }
        .top-links {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 20px;
        }
        .download-btn {
            background: linear-gradient(90deg, #6d28d9 0%, #4c1d95 100%);
            color: white;
            padding: 6px 12px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s;
        }
        .download-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(109, 40, 217, 0.4);
        }
        .social-links {
            display: flex;
            gap: 12px;
        }
        .social-links a {
            color: #a1a1aa;
            font-size: 16px;
            transition: all 0.3s;
        }
        .social-links a:hover {
            color: #6d28d9;
            transform: translateY(-2px);
        }
        .main-header {
            padding: 20px 0;
            background-color: rgba(15, 15, 26, 0.9);
            backdrop-filter: blur(8px);
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        .logo-img {
            height: 40px;
        }
        .navbar-nav {
            gap: 20px;
        }
        .nav-link {
            color: #e0e0e0 !important;
            font-weight: 600;
            position: relative;
            padding: 8px 0 !important;
        }
        .nav-link:hover {
            color: #6d28d9 !important;
        }
        .nav-link:after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: 0;
            left: 0;
            background-color: #6d28d9;
            transition: width 0.3s;
        }
        .nav-link:hover:after {
            width: 100%;
        }
        .dropdown-menu {
            background-color: #1a1a2e;
            border: 1px solid #2a2a4a;
        }
        .dropdown-item {
            color: #e0e0e0;
        }
        .dropdown-item:hover {
            background-color: #6d28d9;
            color: white;
        }
        @media (max-width: 992px) {
            .navbar-nav {
                padding-top: 20px;
            }
            .nav-link {
                padding: 10px 0 !important;
            }
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Oxanium:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
    <!-- Top Bar -->
    <div class="top-bar">
        <div class="container">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div class="server-status">
                    <span class="status-dot online"></span>
                    <span>Server Status: <strong>Online</strong> - 12,543 players</span>
                </div>
                <div class="top-links">
                    <a href="#" class="download-btn">Download Client</a>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-discord"></i></a>
                        <a href="#"><i class="fab fa-twitch"></i></a>
                        <a href="#"><i class="fab fa-youtube"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>

  <!-- Modern Header -->
<header class="main-header" style="background:#0f0f1a; padding:15px 0; border-bottom:1px solid #1e1e2e;">
    <div class="container" style="max-width:1200px; margin:0 auto;">
        <nav style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap;">
            
            <!-- Logo + Brand Name -->
            <a href="index.php" style="display: flex; align-items: center; text-decoration: none;">
                <img src="1.png" alt="BattleonForgett" style="height:50px; width:auto; margin-right:10px;">
                <span style="font-size:24px; color:#ffffff; font-weight:700;">BattleonForgett</span>
            </a>

            <!-- Navigation Links -->
            <div id="navbarContent" style="display: flex; align-items: center; gap: 25px; flex-wrap: wrap;">
                <a href="index.php" style="color: #00ffd5; text-decoration: none; font-weight: 600; font-size:16px;">Home</a>
                <a href="service1.php" style="color: #ffffff; text-decoration: none; font-weight: 600; font-size:16px;">Games</a>
                <a href="service2.php" style="color: #ffffff; text-decoration: none; font-weight: 600; font-size:16px;">Tournaments</a>
                <a href="news.php" style="color: #ffffff; text-decoration: none; font-weight: 600; font-size:16px;">News</a>
                <a href="community.php" style="color: #ffffff; text-decoration: none; font-weight: 600; font-size:16px;">Community</a>
                <a href="shop.php" style="color: #ffffff; text-decoration: none; font-weight: 600; font-size:16px;">Shop</a>
                <a href="contact.php" style="color: #ffffff; text-decoration: none; font-weight: 600; font-size:16px;">Support</a>

                <!-- Login Button -->
                <a href="signin.php" style="background:#00ffd5; color:#0f0f1a; padding:8px 20px; border-radius:6px; font-weight:600; text-decoration:none; font-size:16px; transition:0.3s;">
                    Login
                </a>
            </div>
        </nav>
    </div>
</header>



</body>

</html>