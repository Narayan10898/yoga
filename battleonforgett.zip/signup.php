<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BattleonForgett | Home - Competitive Gaming Platform</title>
    <style>
        body {
            font-family: 'Oxanium', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #0f0f1a;
            color: #e0e0e0;
        }
        .top-bar {
            background: linear-gradient(90deg, #1a1a2e 0%, #16213e 100%);
            padding: 8px 0;
            border-bottom: 1px solid #2a2a4a;
        }
        .server-status {
            display: flex;
            align-items: center;
            font-size: 14px;
        }
        .status-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            margin-right: 8px;
        }
        .online {
            background-color: #4ade80;
            box-shadow: 0 0 8px #4ade80;
        }
        .top-links {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 20px;
        }
        .download-btn {
            background: linear-gradient(90deg, #6d28d9 0%, #4c1d95 100%);
            color: white;
            padding: 6px 12px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s;
        }
        .download-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(109, 40, 217, 0.4);
        }
        .social-links {
            display: flex;
            gap: 12px;
        }
        .social-links a {
            color: #a1a1aa;
            font-size: 16px;
            transition: all 0.3s;
        }
        .social-links a:hover {
            color: #6d28d9;
            transform: translateY(-2px);
        }
        .main-header {
            padding: 20px 0;
            background-color: rgba(15, 15, 26, 0.9);
            backdrop-filter: blur(8px);
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        .logo-img {
            height: 40px;
        }
        .navbar-nav {
            gap: 20px;
        }
        .nav-link {
            color: #e0e0e0 !important;
            font-weight: 600;
            position: relative;
            padding: 8px 0 !important;
        }
        .nav-link:hover {
            color: #6d28d9 !important;
        }
        .nav-link:after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: 0;
            left: 0;
            background-color: #6d28d9;
            transition: width 0.3s;
        }
        .nav-link:hover:after {
            width: 100%;
        }
        .dropdown-menu {
            background-color: #1a1a2e;
            border: 1px solid #2a2a4a;
        }
        .dropdown-item {
            color: #e0e0e0;
        }
        .dropdown-item:hover {
            background-color: #6d28d9;
            color: white;
        }
        @media (max-width: 992px) {
            .navbar-nav {
                padding-top: 20px;
            }
            .nav-link {
                padding: 10px 0 !important;
            }
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Oxanium:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<?php include 'header.php'?>


<!-- BattleonForgett: Sign-Up Page -->
<section style="background: url('12.jpg') no-repeat center center/cover; min-height: 100vh; display: flex; align-items: center; justify-content: center; font-family: 'Segoe UI', sans-serif;">

  <div style="background: rgba(18, 18, 28, 0.95); padding: 50px 40px; max-width: 500px; width: 100%; border-radius: 18px; box-shadow: 0 0 25px rgba(0,255,200,0.2); color: #fff;">
    
    <!-- Title -->
    <div style="text-align: center; margin-bottom: 30px;">
      <h1 style="color: #00ffd0; font-size: 34px;">⚔️ Join BattleonForgett</h1>
      <p style="color: #bbb;">Unleash your warrior. Create your gamer profile now.</p>
    </div>

    <!-- Signup Form -->
    <form>
      <label style="display: block; margin-bottom: 6px;">Username</label>
      <input type="text" placeholder="GamerLegend22" required style="width: 100%; padding: 12px; border-radius: 8px; background: #2a2a3a; border: none; margin-bottom: 18px; color: #fff;">

      <label style="display: block; margin-bottom: 6px;">Email Address</label>
      <input type="email" placeholder="you@battleon.com" required style="width: 100%; padding: 12px; border-radius: 8px; background: #2a2a3a; border: none; margin-bottom: 18px; color: #fff;">

      <label style="display: block; margin-bottom: 6px;">Password</label>
      <input type="password" placeholder="Create strong password" required style="width: 100%; padding: 12px; border-radius: 8px; background: #2a2a3a; border: none; margin-bottom: 18px; color: #fff;">

      <label style="display: block; margin-bottom: 6px;">Confirm Password</label>
      <input type="password" placeholder="Re-enter password" required style="width: 100%; padding: 12px; border-radius: 8px; background: #2a2a3a; border: none; margin-bottom: 20px; color: #fff;">

      <label style="display: flex; align-items: center; font-size: 14px; margin-bottom: 18px;">
        <input type="checkbox" required style="margin-right: 8px;"> I agree to the <a href="termscondition.php" style="color: #00ffd0; margin-left: 5px;">Terms & Conditions</a>
      </label>

      <label style="display: flex; align-items: center; font-size: 14px; margin-bottom: 25px;">
        <input type="checkbox" style="margin-right: 8px;"> Subscribe to BattleonForgett news & updates
      </label>

      <button type="submit" style="width: 100%; background: #00ffd0; color: #000; padding: 14px; font-weight: bold; border: none; border-radius: 10px; cursor: pointer; font-size: 16px;">Create Account</button>
    </form>

    <!-- Social Sign-Up -->
    <div style="text-align: center; margin: 30px 0 20px;">
      <p style="color: #888;">Or sign up using</p>
      <div style="display: flex; justify-content: center; gap: 10px; margin-top: 10px;">
        <button style="padding: 10px 20px; background: #3b5998; border: none; color: #fff; border-radius: 6px; cursor: pointer;">Facebook</button>
        <button style="padding: 10px 20px; background: #1da1f2; border: none; color: #fff; border-radius: 6px; cursor: pointer;">Twitter</button>
        <button style="padding: 10px 20px; background: #db4437; border: none; color: #fff; border-radius: 6px; cursor: pointer;">Google</button>
      </div>
    </div>

    <!-- Already have an account -->
    <p style="text-align: center; color: #bbb; margin-top: 30px;">Already registered? <a href="signup.php" style="color: #00ffd0;">Login Here</a></p>

    <!-- Password Tips -->
    <div style="margin-top: 40px; background: #1a1a2f; padding: 15px; border-radius: 10px; font-size: 14px; color: #aaa;">
      <strong>🧠 Tip:</strong> Use a strong password with uppercase, numbers, and special characters. Never reuse your BattleonForgett password elsewhere.
    </div>

  </div>
</section>



<?php include 'footer.php'?>
    <a id="scroll-top"></a>

    <!-- Javascript -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery.easing.js"></script>

    <script src="assets/js/plugin.js"></script>
    <script src="assets/js/count-down.js"></script>
    <script src="assets/js/shortcodes.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>