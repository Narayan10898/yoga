<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BattleonForgett | Home - Competitive Gaming Platform</title>
    <style>
        body {
            font-family: 'Oxanium', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #0f0f1a;
            color: #e0e0e0;
        }
        .top-bar {
            background: linear-gradient(90deg, #1a1a2e 0%, #16213e 100%);
            padding: 8px 0;
            border-bottom: 1px solid #2a2a4a;
        }
        .server-status {
            display: flex;
            align-items: center;
            font-size: 14px;
        }
        .status-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            margin-right: 8px;
        }
        .online {
            background-color: #4ade80;
            box-shadow: 0 0 8px #4ade80;
        }
        .top-links {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 20px;
        }
        .download-btn {
            background: linear-gradient(90deg, #6d28d9 0%, #4c1d95 100%);
            color: white;
            padding: 6px 12px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s;
        }
        .download-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(109, 40, 217, 0.4);
        }
        .social-links {
            display: flex;
            gap: 12px;
        }
        .social-links a {
            color: #a1a1aa;
            font-size: 16px;
            transition: all 0.3s;
        }
        .social-links a:hover {
            color: #6d28d9;
            transform: translateY(-2px);
        }
        .main-header {
            padding: 20px 0;
            background-color: rgba(15, 15, 26, 0.9);
            backdrop-filter: blur(8px);
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        .logo-img {
            height: 40px;
        }
        .navbar-nav {
            gap: 20px;
        }
        .nav-link {
            color: #e0e0e0 !important;
            font-weight: 600;
            position: relative;
            padding: 8px 0 !important;
        }
        .nav-link:hover {
            color: #6d28d9 !important;
        }
        .nav-link:after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: 0;
            left: 0;
            background-color: #6d28d9;
            transition: width 0.3s;
        }
        .nav-link:hover:after {
            width: 100%;
        }
        .dropdown-menu {
            background-color: #1a1a2e;
            border: 1px solid #2a2a4a;
        }
        .dropdown-item {
            color: #e0e0e0;
        }
        .dropdown-item:hover {
            background-color: #6d28d9;
            color: white;
        }
        @media (max-width: 992px) {
            .navbar-nav {
                padding-top: 20px;
            }
            .nav-link {
                padding: 10px 0 !important;
            }
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Oxanium:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<?php include 'header.php'?>


<!-- Contact Us Page: BattleonForgett -->
<section style="background: url('25.jpg') no-repeat center center/cover; padding: 80px 20px; font-family: 'Segoe UI', sans-serif; color: #ffffff;">

  <!-- Header -->
  <div style="max-width: 1200px; margin: auto; text-align: center; margin-bottom: 60px;">
    <h1 style="font-size: 42px; color: #00ffd0; margin-bottom: 10px;">📨 Contact BattleonForgett</h1>
    <p style="font-size: 18px; color: #d0d0d0;">We’re here to answer your questions, resolve your issues, and hear your legendary tales!</p>
  </div>

  <!-- Contact Info & Form Section -->
  <div style="max-width: 1200px; margin: auto; display: flex; flex-wrap: wrap; gap: 40px; justify-content: center;">

    <!-- Contact Details -->
    <div style="flex: 1; min-width: 320px; background: rgba(30,30,40,0.95); padding: 30px; border-radius: 16px;">
      <h2 style="color: #ff4081; font-size: 24px; margin-bottom: 20px;">📍 Reach Us</h2>
      <p><strong>Email:</strong> support@battleonforgett.com</p>
      <p><strong>Guild Headquarters:</strong> 321 Legends Pass, Rift Realm, GA 54554</p>
      <p><strong>Phone:</strong> +1 (555) 987-4321</p>
      <p><strong>Support Hours:</strong> Mon - Sat / 9 AM - 7 PM (EST)</p>
      <hr style="margin: 20px 0; border-color: #444;">
      <h3 style="color: #ffd740;">⚔️ Support Topics</h3>
      <ul style="padding-left: 20px; color: #ccc;">
        <li>Game Account Help</li>
        <li>Technical Issues / Bugs</li>
        <li>Merchandise Order Status</li>
        <li>Guild / Player Reports</li>
        <li>Business & Press Inquiries</li>
      </ul>
    </div>

    <!-- Contact Form -->
    <div style="flex: 1; min-width: 320px; background: rgba(30,30,40,0.95); padding: 30px; border-radius: 16px;">
      <h2 style="color: #00e5ff; font-size: 24px; margin-bottom: 20px;">📝 Send Us a Message</h2>
      <form style="display: flex; flex-direction: column; gap: 16px;">
        <input type="text" placeholder="Your Full Name" style="padding: 12px; border-radius: 8px; border: none; outline: none; font-size: 16px;">
        <input type="email" placeholder="Your Email Address" style="padding: 12px; border-radius: 8px; border: none; outline: none; font-size: 16px;">
        <select style="padding: 12px; border-radius: 8px; border: none; outline: none; font-size: 16px;">
          <option>Select Topic</option>
          <option>Game Support</option>
          <option>Bug Report</option>
          <option>Merch Order</option>
          <option>Business Inquiry</option>
        </select>
        <textarea rows="6" placeholder="Your Message" style="padding: 12px; border-radius: 8px; border: none; outline: none; font-size: 16px;"></textarea>
        <button type="submit" style="padding: 14px; background: #00ffd0; color: #000; font-weight: bold; border: none; border-radius: 10px; font-size: 16px;">🚀 Submit Message</button>
      </form>
    </div>

  </div>


  <!-- Community CTA -->
  <div style="max-width: 1200px; margin: 80px auto 0; text-align: center;">
    <h2 style="color: #ffffff; font-size: 28px;">💬 Join the Battleon Community</h2>
    <p style="color: #cccccc;">Have questions, tips, or want to connect with fellow heroes? Join our forums and Discord for 24/7 support and camaraderie.</p>
    <a href="#" style="display: inline-block; background: #7289da; color: #fff; padding: 14px 28px; font-weight: bold; border-radius: 30px; text-decoration: none; margin-top: 20px;">Join Our Discord</a>
  </div>

</section>



<?php include 'footer.php'?>


    <a id="scroll-top"></a>

    <!-- Javascript -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery.easing.js"></script>

    <script src="assets/js/plugin.js"></script>
    <script src="assets/js/count-down.js"></script>
    <script src="assets/js/shortcodes.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>