<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie" xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<!--<![endif]-->

<head>
    <!-- Basic Page Needs -->
    <meta charset="utf-8">
    <title>hulksprinkwhisker | Home</title>

    <meta name="author" content="themesflat.com">

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- Theme Style -->
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">

    <!-- Reponsive -->
    <link rel="stylesheet" type="text/css" href="assets/css/responsive.css">

    <!-- Favicon and Touch Icons  -->
    <link rel="shortcut icon" href="assets/icon/Favicon.png">
    <link rel="apple-touch-icon-precomposed" href="assets/icon/Favicon.png">

</head>

<footer style="background: linear-gradient(to bottom, #0a0a16, #070710); padding: 80px 0 0; position: relative; overflow: hidden;">
  <!-- Decorative elements -->
  <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background-image: radial-gradient(rgba(0, 180, 255, 0.05) 1px, transparent 1px); background-size: 40px 40px; z-index: 0;"></div>
  
  <div style="position: relative; z-index: 1; max-width: 1200px; margin: 0 auto; padding: 0 20px;">
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 40px; margin-bottom: 60px;">
      <!-- Brand Info -->
      <div>
        <div style="display: flex; align-items: center; margin-bottom: 20px;">
          <img src="1.png" alt="BattleonForgett Logo" style="height: 40px; margin-right: 15px;">
          <h3 style="font-size: 1.8rem; margin: 0; background: linear-gradient(90deg, #00f0ff, #0084ff); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">BATTLEONFORGETT</h3>
        </div>
        <p style="color: #aaa; line-height: 1.6; margin-bottom: 25px;">
          The ultimate platform for competitive gaming and esports. Join millions of players worldwide in the next evolution of digital combat.
        </p>
        <div style="display: flex; gap: 15px;">
          <a href="#" style="color: #00f0ff; font-size: 1.2rem;"><i class="fab fa-discord"></i></a>
          <a href="#" style="color: #00f0ff; font-size: 1.2rem;"><i class="fab fa-twitch"></i></a>
          <a href="#" style="color: #00f0ff; font-size: 1.2rem;"><i class="fab fa-twitter"></i></a>
          <a href="#" style="color: #00f0ff; font-size: 1.2rem;"><i class="fab fa-youtube"></i></a>
          <a href="#" style="color: #00f0ff; font-size: 1.2rem;"><i class="fab fa-instagram"></i></a>
        </div>
      </div>

      <!-- Quick Links -->
      <div>
        <h4 style="color: #fff; font-size: 1.2rem; margin-bottom: 20px; text-transform: uppercase; letter-spacing: 1px;">Quick Links</h4>
        <ul style="list-style: none; padding: 0; margin: 0;">
          <li style="margin-bottom: 12px;"><a href="index.php" style="color: #aaa; text-decoration: none; transition: all 0.3s;">Home</a></li>
          <li style="margin-bottom: 12px;"><a href="service2.php" style="color: #aaa; text-decoration: none; transition: all 0.3s;">Tournaments</a></li>
          <li style="margin-bottom: 12px;"><a href="community.php" style="color: #aaa; text-decoration: none; transition: all 0.3s;">Leaderboards</a></li>
          <li style="margin-bottom: 12px;"><a href="news.php" style="color: #aaa; text-decoration: none; transition: all 0.3s;">News & Updates</a></li>
          <li style="margin-bottom: 12px;"><a href="contact.php" style="color: #aaa; text-decoration: none; transition: all 0.3s;">Support</a></li>
        </ul>
      </div>

      <!-- Legal -->
      <div>
        <h4 style="color: #fff; font-size: 1.2rem; margin-bottom: 20px; text-transform: uppercase; letter-spacing: 1px;">Legal</h4>
        <ul style="list-style: none; padding: 0; margin: 0;">
          <li style="margin-bottom: 12px;"><a href="termscondition.php" style="color: #aaa; text-decoration: none; transition: all 0.3s;">Terms of Service</a></li>
          <li style="margin-bottom: 12px;"><a href="privacypolicy.php" style="color: #aaa; text-decoration: none; transition: all 0.3s;">Privacy Policy</a></li>
          <li style="margin-bottom: 12px;"><a href="contact.php" style="color: #aaa; text-decoration: none; transition: all 0.3s;">Refund Policy</a></li>
          <li style="margin-bottom: 12px;"><a href="#" style="color: #aaa; text-decoration: none; transition: all 0.3s;">EULA</a></li>
        </ul>
      </div>

      <!-- Newsletter -->
      <div>
        <h4 style="color: #fff; font-size: 1.2rem; margin-bottom: 20px; text-transform: uppercase; letter-spacing: 1px;">Stay Updated</h4>
        <p style="color: #aaa; line-height: 1.6; margin-bottom: 20px;">
          Subscribe to get exclusive tournament invites, game updates, and special offers.
        </p>
        <form style="display: flex; gap: 10px;">
          <input type="email" placeholder="Your Email" style="flex: 1; padding: 12px; border-radius: 5px; border: none; background: rgba(255,255,255,0.1); color: #fff;">
          <button type="submit" style="background: linear-gradient(90deg, #00f0ff, #0084ff); border: none; color: #000; padding: 0 20px; border-radius: 5px; font-weight: 700; cursor: pointer;">
            <i class="fas fa-paper-plane"></i>
          </button>
        </form>
        <div style="margin-top: 20px; display: flex; gap: 15px;">
          <img src="7.jpg" alt="App Store" style="height: 40px;">
          <img src="4.jpg" alt="Google Play" style="height: 40px;">
        </div>
      </div>
    </div>

    <!-- Divider -->
    <div style="height: 1px; background: rgba(255,255,255,0.1); margin: 40px 0;"></div>

    <!-- Copyright -->
    <div style="display: flex; justify-content: space-between; align-items: center; padding-bottom: 40px; flex-wrap: wrap; gap: 20px;">
      <div style="color: #666; font-size: 0.9rem;">
        © 2025 BattleonForgett. All rights reserved.
      </div>
      <div style="display: flex; gap: 20px;">
        <a href="#" style="color: #666; text-decoration: none; font-size: 0.9rem;">Security</a>
        <a href="#" style="color: #666; text-decoration: none; font-size: 0.9rem;">Legal</a>
        <a href="#" style="color: #666; text-decoration: none; font-size: 0.9rem;">Privacy Center</a>
      </div>
    </div>
  </div>
</footer>

            

   
</body>

</html>