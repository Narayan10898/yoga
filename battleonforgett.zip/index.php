<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BattleonForgett | Home - Competitive Gaming Platform</title>
    <style>
        body {
            font-family: 'Oxanium', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #0f0f1a;
            color: #e0e0e0;
        }
        .top-bar {
            background: linear-gradient(90deg, #1a1a2e 0%, #16213e 100%);
            padding: 8px 0;
            border-bottom: 1px solid #2a2a4a;
        }
        .server-status {
            display: flex;
            align-items: center;
            font-size: 14px;
        }
        .status-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            margin-right: 8px;
        }
        .online {
            background-color: #4ade80;
            box-shadow: 0 0 8px #4ade80;
        }
        .top-links {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 20px;
        }
        .download-btn {
            background: linear-gradient(90deg, #6d28d9 0%, #4c1d95 100%);
            color: white;
            padding: 6px 12px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s;
        }
        .download-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(109, 40, 217, 0.4);
        }
        .social-links {
            display: flex;
            gap: 12px;
        }
        .social-links a {
            color: #a1a1aa;
            font-size: 16px;
            transition: all 0.3s;
        }
        .social-links a:hover {
            color: #6d28d9;
            transform: translateY(-2px);
        }
        .main-header {
            padding: 20px 0;
            background-color: rgba(15, 15, 26, 0.9);
            backdrop-filter: blur(8px);
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        .logo-img {
            height: 40px;
        }
        .navbar-nav {
            gap: 20px;
        }
        .nav-link {
            color: #e0e0e0 !important;
            font-weight: 600;
            position: relative;
            padding: 8px 0 !important;
        }
        .nav-link:hover {
            color: #6d28d9 !important;
        }
        .nav-link:after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: 0;
            left: 0;
            background-color: #6d28d9;
            transition: width 0.3s;
        }
        .nav-link:hover:after {
            width: 100%;
        }
        .dropdown-menu {
            background-color: #1a1a2e;
            border: 1px solid #2a2a4a;
        }
        .dropdown-item {
            color: #e0e0e0;
        }
        .dropdown-item:hover {
            background-color: #6d28d9;
            color: white;
        }
        @media (max-width: 992px) {
            .navbar-nav {
                padding-top: 20px;
            }
            .nav-link {
                padding: 10px 0 !important;
            }
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Oxanium:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<?php include 'header.php'?>



<section class="hero-slider" style="position: relative; overflow: hidden; height: 90vh;">
    <!-- Main Slider -->
    <div class="slider-container" style="height: 100%;">
        <div class="slide active" style="background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url('https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80') no-repeat center center/cover; height: 100%; display: flex; align-items: center;">
            <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 0 20px;">
                <div class="slide-content" style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap;">
                    <div class="text-content" style="flex: 1; min-width: 300px; padding: 20px;">
                        <h1 style="font-size: 3.5rem; color: #fff; margin-bottom: 20px; font-weight: 800; text-transform: uppercase; line-height: 1.2;">
                            <span style="color: #00f0ff;">Dominate</span> The Battlefield
                        </h1>
                        <p style="color: #ccc; font-size: 1.2rem; margin-bottom: 30px; max-width: 600px;">
                            Join the ultimate gaming arena where legends are born. Compete in high-stakes tournaments, climb leaderboards, and forge your legacy in our thriving esports community.
                        </p>
                        <div class="cta-buttons" style="display: flex; gap: 20px; flex-wrap: wrap;">
                            <a href="tournaments.php" style="background: linear-gradient(135deg, #00f0ff 0%, #0084ff 100%); color: #000; padding: 15px 30px; border-radius: 5px; text-decoration: none; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; transition: all 0.3s;">
                                Join Tournament
                            </a>
                            <a href="register.php" style="background: transparent; color: #fff; padding: 15px 30px; border-radius: 5px; text-decoration: none; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; border: 2px solid #00f0ff; transition: all 0.3s;">
                                Free Sign Up
                            </a>
                        </div>
                        <div class="stats" style="display: flex; gap: 30px; margin-top: 40px;">
                            <div class="stat-item">
                                <div style="font-size: 2.5rem; color: #00f0ff; font-weight: 700;">250K+</div>
                                <div style="color: #aaa;">Active Players</div>
                            </div>
                            <div class="stat-item">
                                <div style="font-size: 2.5rem; color: #00f0ff; font-weight: 700;">$1M+</div>
                                <div style="color: #aaa;">In Prizes</div>
                            </div>
                            <div class="stat-item">
                                <div style="font-size: 2.5rem; color: #00f0ff; font-weight: 700;">24/7</div>
                                <div style="color: #aaa;">Competitions</div>
                            </div>
                        </div>
                    </div>
                    <div class="image-content" style="flex: 1; min-width: 300px; position: relative;">
                        <img src="25.jpg" alt="Esports Champion" style="width: 100%; border-radius: 10px; box-shadow: 0 20px 40px rgba(0,0,0,0.5); transform: perspective(1000px) rotateY(-15deg);">
                        <div style="position: absolute; bottom: -20px; right: -20px; background: rgba(0,0,0,0.7); padding: 10px 20px; border-radius: 5px; border-left: 4px solid #00f0ff;">
                            <div style="color: #00f0ff; font-weight: 700;">LIVE TOURNAMENT</div>
                            <div style="color: #fff;">Season 5 Finals</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Slider Navigation -->
    <div class="slider-nav" style="position: absolute; bottom: 50px; left: 50%; transform: translateX(-50%); display: flex; gap: 15px;">
        <button class="nav-dot active" style="width: 12px; height: 12px; border-radius: 50%; background: #00f0ff; border: none; cursor: pointer; opacity: 1;"></button>
        <button class="nav-dot" style="width: 12px; height: 12px; border-radius: 50%; background: #fff; border: none; cursor: pointer; opacity: 0.5;"></button>
        <button class="nav-dot" style="width: 12px; height: 12px; border-radius: 50%; background: #fff; border: none; cursor: pointer; opacity: 0.5;"></button>
    </div>
</section>


<section class="gaming-features" style="background: radial-gradient(circle at center, #0f0f1a 0%, #070710 100%); padding: 80px 0; position: relative; overflow: hidden;">
  <!-- Animated background elements -->
  <div class="grid-pattern" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background-image: radial-gradient(rgba(0, 240, 255, 0.1) 1px, transparent 1px); background-size: 30px 30px; z-index: 0;"></div>
  
  <div class="container" style="position: relative; z-index: 1;">
    <div class="section-header" style="text-align: center; margin-bottom: 60px;">
      <h2 style="font-size: 2.8rem; color: #00f0ff; margin-bottom: 15px; font-weight: 800; text-transform: uppercase; letter-spacing: 2px;">
        NEXT-GEN GAMING TECH
      </h2>
      <p style="color: #aaa; font-size: 1.2rem; max-width: 700px; margin: 0 auto;">
        BattleonForgett brings you cutting-edge gaming technologies that redefine immersion and competition
      </p>
    </div>

    <div class="features-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(350px, 1fr)); gap: 30px;">
      <!-- Feature 1: Cloud Gaming -->
      <div class="feature-card" style="background: rgba(30, 30, 50, 0.7); border-radius: 15px; overflow: hidden; border: 1px solid rgba(0, 240, 255, 0.2); transition: all 0.3s ease; position: relative;">
        <div class="feature-badge" style="position: absolute; top: 20px; right: 20px; background: rgba(0, 240, 255, 0.2); color: #00f0ff; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: 700;">NEW</div>
        <div class="feature-img" style="height: 200px; overflow: hidden;">
          <img src="9.jpg">
        </div>
        <div class="feature-content" style="padding: 25px;">
          <div class="feature-icon" style="width: 60px; height: 60px; background: rgba(0, 240, 255, 0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 20px;">
            <i class="fas fa-cloud" style="font-size: 1.8rem; color: #00f0ff;"></i>
          </div>
          <h3 style="color: #fff; font-size: 1.5rem; margin-bottom: 15px; font-weight: 700;">Cloud Gaming Arena</h3>
          <p style="color: #aaa; margin-bottom: 25px; line-height: 1.6;">
            Stream AAA titles instantly with zero downloads. Our low-latency cloud platform delivers 4K/120fps gaming to any device with BattleonForgett's proprietary streaming tech.
          </p>
          <a href="#" class="feature-link" style="color: #00f0ff; text-decoration: none; font-weight: 700; display: inline-flex; align-items: center; gap: 8px;">
            Explore Cloud Gaming <i class="fas fa-arrow-right" style="transition: transform 0.3s ease;"></i>
          </a>
        </div>
      </div>

      <!-- Feature 2: VR Combat -->
      <div class="feature-card" style="background: rgba(30, 30, 50, 0.7); border-radius: 15px; overflow: hidden; border: 1px solid rgba(0, 240, 255, 0.2); transition: all 0.3s ease;">
        <div class="feature-img" style="height: 200px; overflow: hidden;">
          <img src="https://images.unsplash.com/photo-1593508512255-86ab42a8e620?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2187&q=80" alt="VR Gaming" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease;">
        </div>
        <div class="feature-content" style="padding: 25px;">
          <div class="feature-icon" style="width: 60px; height: 60px; background: rgba(0, 240, 255, 0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 20px;">
            <i class="fas fa-vr-cardboard" style="font-size: 1.8rem; color: #00f0ff;"></i>
          </div>
          <h3 style="color: #fff; font-size: 1.5rem; margin-bottom: 15px; font-weight: 700;">VR Combat Zones</h3>
          <p style="color: #aaa; margin-bottom: 25px; line-height: 1.6;">
            Fully immersive VR battlegrounds with full-body tracking. Experience next-gen warfare with haptic feedback vests and motion platforms that simulate every explosion.
          </p>
          <a href="#" class="feature-link" style="color: #00f0ff; text-decoration: none; font-weight: 700; display: inline-flex; align-items: center; gap: 8px;">
            Enter VR Arena <i class="fas fa-arrow-right" style="transition: transform 0.3s ease;"></i>
          </a>
        </div>
      </div>

      <!-- Feature 3: Mobile eSports -->
      <div class="feature-card" style="background: rgba(30, 30, 50, 0.7); border-radius: 15px; overflow: hidden; border: 1px solid rgba(0, 240, 255, 0.2); transition: all 0.3s ease;">
        <div class="feature-badge" style="position: absolute; top: 20px; right: 20px; background: rgba(255, 50, 100, 0.2); color: #ff3264; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: 700;">POPULAR</div>
        <div class="feature-img" style="height: 200px; overflow: hidden;">
          <img src="https://images.unsplash.com/photo-1553481187-be93c21490a9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80" alt="Mobile eSports" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease;">
        </div>
        <div class="feature-content" style="padding: 25px;">
          <div class="feature-icon" style="width: 60px; height: 60px; background: rgba(0, 240, 255, 0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 20px;">
            <i class="fas fa-mobile-alt" style="font-size: 1.8rem; color: #00f0ff;"></i>
          </div>
          <h3 style="color: #fff; font-size: 1.5rem; margin-bottom: 15px; font-weight: 700;">Mobile eSports Pro</h3>
          <p style="color: #aaa; margin-bottom: 25px; line-height: 1.6;">
            Compete in official tournaments for PUBG Mobile, COD Mobile and more. Our mobile-optimized servers ensure ultra-low latency for competitive advantage.
          </p>
          <a href="#" class="feature-link" style="color: #00f0ff; text-decoration: none; font-weight: 700; display: inline-flex; align-items: center; gap: 8px;">
            View Tournaments <i class="fas fa-arrow-right" style="transition: transform 0.3s ease;"></i>
          </a>
        </div>
      </div>

      <!-- Feature 4: Motion Combat -->
      <div class="feature-card" style="background: rgba(30, 30, 50, 0.7); border-radius: 15px; overflow: hidden; border: 1px solid rgba(0, 240, 255, 0.2); transition: all 0.3s ease;">
        <div class="feature-img" style="height: 200px; overflow: hidden;">
          <img src="https://images.unsplash.com/photo-1546443046-ed1ce6ffd1ab?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80" alt="Motion Gaming" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease;">
        </div>
        <div class="feature-content" style="padding: 25px;">
          <div class="feature-icon" style="width: 60px; height: 60px; background: rgba(0, 240, 255, 0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 20px;">
            <i class="fas fa-running" style="font-size: 1.8rem; color: #00f0ff;"></i>
          </div>
          <h3 style="color: #fff; font-size: 1.5rem; margin-bottom: 15px; font-weight: 700;">Motion Combat</h3>
          <p style="color: #aaa; margin-bottom: 25px; line-height: 1.6;">
            Full-body motion tracking turns your movements into in-game actions. Our dojo-style arenas combine fitness with competitive gaming.
          </p>
          <a href="#" class="feature-link" style="color: #00f0ff; text-decoration: none; font-weight: 700; display: inline-flex; align-items: center; gap: 8px;">
            Try Motion Games <i class="fas fa-arrow-right" style="transition: transform 0.3s ease;"></i>
          </a>
        </div>
      </div>

      <!-- Feature 5: AI Arena -->
      <div class="feature-card" style="background: rgba(30, 30, 50, 0.7); border-radius: 15px; overflow: hidden; border: 1px solid rgba(0, 240, 255, 0.2); transition: all 0.3s ease;">
        <div class="feature-badge" style="position: absolute; top: 20px; right: 20px; background: rgba(255, 200, 0, 0.2); color: #ffc800; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: 700;">BETA</div>
        <div class="feature-img" style="height: 200px; overflow: hidden;">
          <img src="8.jpg">
        </div>
        <div class="feature-content" style="padding: 25px;">
          <div class="feature-icon" style="width: 60px; height: 60px; background: rgba(0, 240, 255, 0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 20px;">
            <i class="fas fa-robot" style="font-size: 1.8rem; color: #00f0ff;"></i>
          </div>
          <h3 style="color: #fff; font-size: 1.5rem; margin-bottom: 15px; font-weight: 700;">AI Battle Arena</h3>
          <p style="color: #aaa; margin-bottom: 25px; line-height: 1.6;">
            Face neural network opponents that learn your tactics in real-time. Our proprietary AI adapts to create the ultimate personalized challenge.
          </p>
          <a href="#" class="feature-link" style="color: #00f0ff; text-decoration: none; font-weight: 700; display: inline-flex; align-items: center; gap: 8px;">
            Challenge AI <i class="fas fa-arrow-right" style="transition: transform 0.3s ease;"></i>
          </a>
        </div>
      </div>

      <!-- Feature 6: Haptic Warfare -->
      <div class="feature-card" style="background: rgba(30, 30, 50, 0.7); border-radius: 15px; overflow: hidden; border: 1px solid rgba(0, 240, 255, 0.2); transition: all 0.3s ease;">
        <div class="feature-img" style="height: 200px; overflow: hidden;">
          <img src="7.jpg">
        </div>
        <div class="feature-content" style="padding: 25px;">
          <div class="feature-icon" style="width: 60px; height: 60px; background: rgba(0, 240, 255, 0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 20px;">
            <i class="fas fa-hand-sparkles" style="font-size: 1.8rem; color: #00f0ff;"></i>
          </div>
          <h3 style="color: #fff; font-size: 1.5rem; margin-bottom: 15px; font-weight: 700;">Haptic Warfare</h3>
          <p style="color: #aaa; margin-bottom: 25px; line-height: 1.6;">
            Full-body haptic suits with 128 feedback zones. Feel every bullet impact, explosion shockwave and environmental effect with military-grade precision.
          </p>
          <a href="#" class="feature-link" style="color: #00f0ff; text-decoration: none; font-weight: 700; display: inline-flex; align-items: center; gap: 8px;">
            Experience Haptics <i class="fas fa-arrow-right" style="transition: transform 0.3s ease;"></i>
          </a>
        </div>
      </div>
    </div>
  </div>
</section>

<style>
  /* Hover effects */
  .feature-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 15px 30px rgba(0, 240, 255, 0.15);
    border-color: rgba(0, 240, 255, 0.4);
  }
  
  .feature-card:hover .feature-img img {
    transform: scale(1.05);
  }
  
  .feature-link:hover i {
    transform: translateX(5px);
  }
  
  /* Responsive adjustments */
  @media (max-width: 768px) {
    .features-grid {
      grid-template-columns: 1fr;
    }
    
    .section-header h2 {
      font-size: 2rem;
    }
  }
</style>



<section style="background: linear-gradient(135deg, #0a0a1a 0%, #1a1a3a 100%); padding: 80px 0; position: relative; overflow: hidden;">
  <!-- Tech grid background -->
  <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background-image: radial-gradient(rgba(0, 180, 255, 0.08) 1px, transparent 1px); background-size: 40px 40px; z-index: 0;"></div>
  
  <div style="position: relative; z-index: 1; max-width: 1200px; margin: 0 auto; padding: 0 20px;">
    
    <!-- Feature 1 -->
    <div style="display: flex; flex-wrap: wrap; align-items: center; margin-bottom: 80px;">
      <div style="flex: 1; min-width: 300px; padding: 20px;">
        <img src="https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80" 
             alt="Future of Gaming" 
             style="width: 100%; height: 350px; object-fit: cover; border-radius: 15px; box-shadow: 0 20px 40px rgba(0,0,0,0.3);">
      </div>
      <div style="flex: 1; min-width: 300px; padding: 20px;">
        <h3 style="font-size: 2.2rem; color: #00ff88; margin-bottom: 20px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px;">
          THE NEXT EVOLUTION OF PLAY
        </h3>
        <p style="font-size: 1.1rem; color: #d1d1d1; line-height: 1.8; margin-bottom: 25px;">
          We're entering a new golden age of gaming where boundaries between reality and virtual worlds blur. Powered by quantum computing prototypes and neural interface research, the games of tomorrow will respond to your thoughts as naturally as your controller does today. Our platform is at the forefront, integrating experimental technologies that will redefine immersion.
        </p>
        <div style="display: flex; gap: 15px;">
          <a href="#" style="background: linear-gradient(90deg, #00ff88 0%, #00cc66 100%); color: #000; padding: 12px 25px; border-radius: 5px; text-decoration: none; font-weight: 700; transition: all 0.3s;">
            Explore Tech
          </a>
          <a href="#" style="background: transparent; color: #00ff88; padding: 12px 25px; border-radius: 5px; text-decoration: none; font-weight: 700; border: 2px solid #00ff88; transition: all 0.3s;">
            Watch Demo
          </a>
        </div>
      </div>
    </div>

    <!-- Feature 2 -->
    <div style="display: flex; flex-wrap: wrap-reverse; align-items: center; margin-bottom: 80px;">
      <div style="flex: 1; min-width: 300px; padding: 20px;">
        <h3 style="font-size: 2.2rem; color: #ff5e5e; margin-bottom: 20px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px;">
          COMPETITIVE GAMING REDEFINED
        </h3>
        <p style="font-size: 1.1rem; color: #d1d1d1; line-height: 1.8; margin-bottom: 25px;">
          Our tournament systems leverage blockchain for tamper-proof results and instant prize distribution. With AI-powered matchmaking that analyzes 200+ performance metrics, you'll always face opponents at your exact skill level. The future of esports is here - where every match feels like the championship finals.
        </p>
        <div style="display: flex; align-items: center; gap: 20px; flex-wrap: wrap;">
          <div style="display: flex; align-items: center; gap: 10px;">
            <div style="width: 12px; height: 12px; background: #ff5e5e; border-radius: 50%;"></div>
            <span style="color: #d1d1d1;">Real-time analytics</span>
          </div>
          <div style="display: flex; align-items: center; gap: 10px;">
            <div style="width: 12px; height: 12px; background: #ff5e5e; border-radius: 50%;"></div>
            <span style="color: #d1d1d1;">Smart contract payouts</span>
          </div>
          <div style="display: flex; align-items: center; gap: 10px;">
            <div style="width: 12px; height: 12px; background: #ff5e5e; border-radius: 50%;"></div>
            <span style="color: #d1d1d1;">3D spectator mode</span>
          </div>
        </div>
      </div>
      <div style="flex: 1; min-width: 300px; padding: 20px;">
        <img src="12.jpg" 
             alt="Competitive Gaming" 
             style="width: 100%; height: 350px; object-fit: cover; border-radius: 15px; box-shadow: 0 20px 40px rgba(0,0,0,0.3);">
      </div>
    </div>

    <!-- Dual Features -->
    <div style="display: flex; flex-wrap: wrap; gap: 30px; margin-bottom: 40px;">
      <div style="flex: 1; min-width: 300px; background: rgba(30, 30, 60, 0.6); border-radius: 15px; padding: 30px; border: 1px solid rgba(0, 180, 255, 0.2);">
        <h3 style="font-size: 1.8rem; color: #ffb86c; margin-bottom: 20px; font-weight: 700;">
          PRECISION ENGINEERED
        </h3>
        <p style="font-size: 1rem; color: #d1d1d1; line-height: 1.8; margin-bottom: 20px;">
          Our proprietary input system reduces latency to imperceptible 2ms response times. Combined with adaptive trigger technology that provides realistic weapon feedback, you'll experience control so precise it feels like an extension of your nervous system.
        </p>
        <div style="height: 2px; background: linear-gradient(90deg, #ffb86c, transparent); margin: 25px 0;"></div>
        <div style="display: flex; justify-content: space-between;">
          <span style="color: #ffb86c; font-weight: 700;">2ms</span>
          <span style="color: #d1d1d1;">Input latency</span>
        </div>
      </div>
      
      <div style="flex: 1; min-width: 300px; background: rgba(30, 30, 60, 0.6); border-radius: 15px; padding: 30px; border: 1px solid rgba(0, 180, 255, 0.2);">
        <h3 style="font-size: 1.8rem; color: #bd93f9; margin-bottom: 20px; font-weight: 700;">
          IMMERSIVE TECH
        </h3>
        <p style="font-size: 1rem; color: #d1d1d1; line-height: 1.8; margin-bottom: 20px;">
          From full-body haptic suits to photorealistic ray tracing, our platform integrates cutting-edge technologies that engage all your senses. Spatial 3D audio precisely positions every footstep and gunshot in 360° space around you.
        </p>
        <div style="height: 2px; background: linear-gradient(90deg, #bd93f9, transparent); margin: 25px 0;"></div>
        <div style="display: flex; justify-content: space-between;">
          <span style="color: #bd93f9; font-weight: 700;">128-zone</span>
          <span style="color: #d1d1d1;">Haptic feedback</span>
        </div>
      </div>
    </div>
  </div>
</section>

            
<section style="background: #0a0a16; padding: 80px 0; position: relative; overflow: hidden;">
  <!-- Decorative elements -->
  <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background-image: radial-gradient(rgba(0, 180, 255, 0.05) 1px, transparent 1px); background-size: 40px 40px; z-index: 0;"></div>
  
  <div style="position: relative; z-index: 1; max-width: 1200px; margin: 0 auto; padding: 0 20px;">
    <!-- Section Header -->
    <div style="text-align: center; margin-bottom: 60px;">
      <h3 style="font-size: 2.5rem; color: #00f0ff; margin-bottom: 15px; font-weight: 800; text-transform: uppercase; letter-spacing: 2px;">
        BATTLEONFORGETT EXCLUSIVES
      </h3>
      <p style="color: #aaa; font-size: 1.2rem; max-width: 700px; margin: 0 auto;">
        Discover the games that are redefining competitive play - available only on BattleonForgett
      </p>
    </div>

    <!-- Game Collection Grid -->
    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(350px, 1fr)); gap: 30px;">
      <!-- Game 1 -->
      <div style="background: rgba(30, 30, 50, 0.7); border-radius: 15px; overflow: hidden; border: 1px solid rgba(0, 240, 255, 0.2); transition: all 0.3s ease; position: relative;">
        <div style="position: absolute; top: 20px; right: 20px; background: rgba(0, 240, 255, 0.2); color: #00f0ff; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: 700;">NEW RELEASE</div>
        <div style="height: 200px; overflow: hidden;">
          <img src="https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80" alt="Nexus Overdrive" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease;">
        </div>
        <div style="padding: 25px;">
          <h4 style="color: #fff; font-size: 1.5rem; margin-bottom: 10px; font-weight: 700;">Nexus Overdrive</h4>
          <p style="color: #aaa; margin-bottom: 20px; line-height: 1.6; font-size: 0.95rem;">
            The fastest battle royale experience with zero loading times. Our proprietary cloud streaming delivers 144fps gameplay at 4K resolution.
          </p>
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
              <div style="color: #00f0ff; font-weight: 700; font-size: 0.9rem;">DEVELOPER</div>
              <div style="color: #fff; font-size: 1rem;">Quantum Forge Studios</div>
            </div>
            <a href="#" style="background: linear-gradient(90deg, #00f0ff 0%, #0084ff 100%); color: #000; padding: 10px 20px; border-radius: 5px; text-decoration: none; font-weight: 700; font-size: 0.9rem;">
              PLAY NOW
            </a>
          </div>
        </div>
      </div>

      <!-- Game 2 -->
      <div style="background: rgba(30, 30, 50, 0.7); border-radius: 15px; overflow: hidden; border: 1px solid rgba(0, 240, 255, 0.2); transition: all 0.3s ease; position: relative;">
        <div style="position: absolute; top: 20px; right: 20px; background: rgba(255, 50, 100, 0.2); color: #ff3264; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: 700;">ESPORTS READY</div>
        <div style="height: 200px; overflow: hidden;">
          <img src="https://images.unsplash.com/photo-1560253023-3ec5d502959f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80" alt="Apex Protocol" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease;">
        </div>
        <div style="padding: 25px;">
          <h4 style="color: #fff; font-size: 1.5rem; margin-bottom: 10px; font-weight: 700;">Apex Protocol</h4>
          <p style="color: #aaa; margin-bottom: 20px; line-height: 1.6; font-size: 0.95rem;">
            Tactical 5v5 shooter with destructible environments and real-time physics. Our anti-cheat system guarantees fair competitive play.
          </p>
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
              <div style="color: #00f0ff; font-weight: 700; font-size: 0.9rem;">DEVELOPER</div>
              <div style="color: #fff; font-size: 1rem;">Neon Hammer Games</div>
            </div>
            <a href="#" style="background: linear-gradient(90deg, #00f0ff 0%, #0084ff 100%); color: #000; padding: 10px 20px; border-radius: 5px; text-decoration: none; font-weight: 700; font-size: 0.9rem;">
              PLAY NOW
            </a>
          </div>
        </div>
      </div>

      <!-- Game 3 -->
      <div style="background: rgba(30, 30, 50, 0.7); border-radius: 15px; overflow: hidden; border: 1px solid rgba(0, 240, 255, 0.2); transition: all 0.3s ease; position: relative;">
        <div style="position: absolute; top: 20px; right: 20px; background: rgba(255, 200, 0, 0.2); color: #ffc800; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: 700;">VR EXCLUSIVE</div>
        <div style="height: 200px; overflow: hidden;">
          <img src="https://images.unsplash.com/photo-1593508512255-86ab42a8e620?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2187&q=80" alt="Voidwalkers" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease;">
        </div>
        <div style="padding: 25px;">
          <h4 style="color: #fff; font-size: 1.5rem; margin-bottom: 10px; font-weight: 700;">Voidwalkers</h4>
          <p style="color: #aaa; margin-bottom: 20px; line-height: 1.6; font-size: 0.95rem;">
            Full-body VR combat with haptic feedback. Our neural interface adapts to your movement style for the most immersive melee combat system ever created.
          </p>
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
              <div style="color: #00f0ff; font-weight: 700; font-size: 0.9rem;">DEVELOPER</div>
              <div style="color: #fff; font-size: 1rem;">Immersive Realms</div>
            </div>
            <a href="#" style="background: linear-gradient(90deg, #00f0ff 0%, #0084ff 100%); color: #000; padding: 10px 20px; border-radius: 5px; text-decoration: none; font-weight: 700; font-size: 0.9rem;">
              PLAY NOW
            </a>
          </div>
        </div>
      </div>

      <!-- Game 4 -->
      <div style="background: rgba(30, 30, 50, 0.7); border-radius: 15px; overflow: hidden; border: 1px solid rgba(0, 240, 255, 0.2); transition: all 0.3s ease; position: relative;">
        <div style="position: absolute; top: 20px; right: 20px; background: rgba(150, 50, 255, 0.2); color: #9632ff; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: 700;">BLOCKCHAIN</div>
        <div style="height: 200px; overflow: hidden;">
          <img src="https://images.unsplash.com/photo-1639762681057-408e52192e55?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2232&q=80" alt="CryptoWars" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease;">
        </div>
        <div style="padding: 25px;">
          <h4 style="color: #fff; font-size: 1.5rem; margin-bottom: 10px; font-weight: 700;">CryptoWars</h4>
          <p style="color: #aaa; margin-bottom: 20px; line-height: 1.6; font-size: 0.95rem;">
            Play-to-earn RTS where every unit is an NFT. Our decentralized marketplace lets you trade assets across multiple blockchain games.
          </p>
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
              <div style="color: #00f0ff; font-weight: 700; font-size: 0.9rem;">DEVELOPER</div>
              <div style="color: #fff; font-size: 1rem;">Decentral Games</div>
            </div>
            <a href="#" style="background: linear-gradient(90deg, #00f0ff 0%, #0084ff 100%); color: #000; padding: 10px 20px; border-radius: 5px; text-decoration: none; font-weight: 700; font-size: 0.9rem;">
              PLAY NOW
            </a>
          </div>
        </div>
      </div>

      <!-- Game 5 -->
      <div style="background: rgba(30, 30, 50, 0.7); border-radius: 15px; overflow: hidden; border: 1px solid rgba(0, 240, 255, 0.2); transition: all 0.3s ease; position: relative;">
        <div style="position: absolute; top: 20px; right: 20px; background: rgba(50, 255, 150, 0.2); color: #32ff96; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: 700;">AI EVOLVING</div>
        <div style="height: 200px; overflow: hidden;">
          <img src="6.jpg" alt="Neural Dawn" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease;">
        </div>
        <div style="padding: 25px;">
          <h4 style="color: #fff; font-size: 1.5rem; margin-bottom: 10px; font-weight: 700;">Neural Dawn</h4>
          <p style="color: #aaa; margin-bottom: 20px; line-height: 1.6; font-size: 0.95rem;">
            The world's first game with self-learning AI enemies. Our neural networks create unique opponents that adapt to your playstyle in real-time.
          </p>
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
              <div style="color: #00f0ff; font-weight: 700; font-size: 0.9rem;">DEVELOPER</div>
              <div style="color: #fff; font-size: 1rem;">DeepMind Studios</div>
            </div>
            <a href="#" style="background: linear-gradient(90deg, #00f0ff 0%, #0084ff 100%); color: #000; padding: 10px 20px; border-radius: 5px; text-decoration: none; font-weight: 700; font-size: 0.9rem;">
              PLAY NOW
            </a>
          </div>
        </div>
      </div>

      <!-- Game 6 -->
      <div style="background: rgba(30, 30, 50, 0.7); border-radius: 15px; overflow: hidden; border: 1px solid rgba(0, 240, 255, 0.2); transition: all 0.3s ease; position: relative;">
        <div style="position: absolute; top: 20px; right: 20px; background: rgba(255, 100, 50, 0.2); color: #ff6432; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: 700;">CROSS-PLATFORM</div>
        <div style="height: 200px; overflow: hidden;">
          <img src="5.jpg" alt="OmniStrike" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease;">
        </div>
        <div style="padding: 25px;">
          <h4 style="color: #fff; font-size: 1.5rem; margin-bottom: 10px; font-weight: 700;">OmniStrike</h4>
          <p style="color: #aaa; margin-bottom: 20px; line-height: 1.6; font-size: 0.95rem;">
            Seamless cross-play between PC, console and mobile. Our universal input system automatically adapts controls for each platform.
          </p>
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
              <div style="color: #00f0ff; font-weight: 700; font-size: 0.9rem;">DEVELOPER</div>
              <div style="color: #fff; font-size: 1rem;">Unified Games</div>
            </div>
            <a href="#" style="background: linear-gradient(90deg, #00f0ff 0%, #0084ff 100%); color: #000; padding: 10px 20px; border-radius: 5px; text-decoration: none; font-weight: 700; font-size: 0.9rem;">
              PLAY NOW
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Game Highlights -->
<section id="highlights" style="padding:70px 20px; background:#0e0e0e; color:#f5f5f5; text-align:center;">
    <h2 style="font-size:38px; color:#00ffd5; margin-bottom:10px;">🎮 Explore Elite Battle Classes</h2>
    <p style="font-size:17px; color:#bbb;">Choose your destiny in the world of BattleonForgett. Each class is a gateway to power, strategy, and survival.</p>

    <div style="display:flex; flex-wrap:wrap; justify-content:center; gap:35px; margin-top:50px;">

        <!-- Void Bladesman -->
        <div style="width:280px; background:#1b1b1b; border-radius:12px; overflow:hidden; box-shadow:0 0 15px rgba(0,255,208,0.1); transition:transform 0.3s;">
            <img src="1.jpg" alt="Void Bladesman" style="width:100%; height:180px; object-fit:cover;">
            <div style="padding:20px;">
                <h3 style="color:#00ffe0; font-size:20px;">Void Bladesman</h3>
                <p style="font-size:14px; color:#ccc;">Harness the shadows of the abyss to deliver rapid strikes and teleport across the battlefield.</p>
            </div>
        </div>

        <!-- Ember Sentinel -->
        <div style="width:280px; background:#1b1b1b; border-radius:12px; overflow:hidden; box-shadow:0 0 15px rgba(255,112,67,0.1); transition:transform 0.3s;">
            <img src="2.jpg" alt="Ember Sentinel" style="width:100%; height:180px; object-fit:cover;">
            <div style="padding:20px;">
                <h3 style="color:#ff7043; font-size:20px;">Ember Sentinel</h3>
                <p style="font-size:14px; color:#ccc;">Control flame and fury. This tank-class scorches enemies with volcanic defense techniques.</p>
            </div>
        </div>

        <!-- Crystal Warden -->
        <div style="width:280px; background:#1b1b1b; border-radius:12px; overflow:hidden; box-shadow:0 0 15px rgba(138,201,255,0.1); transition:transform 0.3s;">
            <img src="3.jpg" alt="Crystal Warden" style="width:100%; height:180px; object-fit:cover;">
            <div style="padding:20px;">
                <h3 style="color:#8ac9ff; font-size:20px;">Crystal Warden</h3>
                <p style="font-size:14px; color:#ccc;">Defensive and mystical, the Warden uses crystal shields and frost barriers to control enemy advances.</p>
            </div>
        </div>

        <!-- Sky Reaper -->
        <div style="width:280px; background:#1b1b1b; border-radius:12px; overflow:hidden; box-shadow:0 0 15px rgba(255,105,180,0.1); transition:transform 0.3s;">
            <img src="4.jpg" alt="Sky Reaper" style="width:100%; height:180px; object-fit:cover;">
            <div style="padding:20px;">
                <h3 style="color:#ff69b4; font-size:20px;">Sky Reaper</h3>
                <p style="font-size:14px; color:#ccc;">Deadly from above, the Sky Reaper uses aerial slashes and thunderstorm blades for lethal precision.</p>
            </div>
        </div>

    </div>
</section>


<section style="background: linear-gradient(to bottom, #0f0c29, #302b63); padding: 80px 0; position: relative;">
  <!-- Decorative elements -->
  <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background-image: radial-gradient(rgba(255,255,255,0.05) 1px, transparent 1px); background-size: 40px 40px; z-index: 0;"></div>
  
  <div style="position: relative; z-index: 1; max-width: 1200px; margin: 0 auto; padding: 0 20px;">
    
    <!-- Section Header -->
    <div style="text-align: center; margin-bottom: 60px;">
      <h3 style="font-size: 2.5rem; color: #fff; margin-bottom: 15px; font-weight: 700; text-transform: uppercase; letter-spacing: 2px;">
        TOP GAMING COLLECTIONS
      </h3>
      <p style="color: #aaa; font-size: 1.2rem; max-width: 700px; margin: 0 auto;">
        Discover this month's hottest releases and upcoming competitive events
      </p>
    </div>

    <div style="display: flex; flex-wrap: wrap; gap: 30px; margin-bottom: 60px;">
      <!-- Game 1 -->
      <div style="flex: 1; min-width: 250px; background: rgba(20, 20, 40, 0.7); border-radius: 15px; overflow: hidden; border: 1px solid rgba(100, 65, 165, 0.3); transition: all 0.3s ease;">
        <div style="height: 200px; overflow: hidden; position: relative;">
          <img src="https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80" 
               alt="Quantum Breakout" 
               style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease;">
          <div style="position: absolute; bottom: 15px; left: 15px; background: rgba(0,0,0,0.7); padding: 5px 15px; border-radius: 20px; color: #00f0ff; font-weight: 700; font-size: 0.9rem;">
            NEW RELEASE
          </div>
        </div>
        <div style="padding: 20px;">
          <h4 style="color: #fff; font-size: 1.3rem; margin-bottom: 10px;">Quantum Breakout</h4>
          <p style="color: #bbb; font-size: 0.9rem; margin-bottom: 15px; line-height: 1.5;">
            Time-bending FPS where you manipulate physics to outsmart enemies
          </p>
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <span style="color: #00f0ff; font-weight: 600;">4.9/5 ★</span>
            <a href="#" style="color: #fff; text-decoration: none; font-size: 0.9rem;">View Details →</a>
          </div>
        </div>
      </div>

      <!-- Game 2 -->
      <div style="flex: 1; min-width: 250px; background: rgba(20, 20, 40, 0.7); border-radius: 15px; overflow: hidden; border: 1px solid rgba(100, 65, 165, 0.3); transition: all 0.3s ease;">
        <div style="height: 200px; overflow: hidden; position: relative;">
          <img src="https://images.unsplash.com/photo-1560253023-3ec5d502959f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80" 
               alt="Neon Overdrive" 
               style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease;">
          <div style="position: absolute; bottom: 15px; left: 15px; background: rgba(0,0,0,0.7); padding: 5px 15px; border-radius: 20px; color: #ff5e5e; font-weight: 700; font-size: 0.9rem;">
            ESPORTS READY
          </div>
        </div>
        <div style="padding: 20px;">
          <h4 style="color: #fff; font-size: 1.3rem; margin-bottom: 10px;">Neon Overdrive</h4>
          <p style="color: #bbb; font-size: 0.9rem; margin-bottom: 15px; line-height: 1.5;">
            High-octane racing combat with destructible environments
          </p>
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <span style="color: #00f0ff; font-weight: 600;">4.7/5 ★</span>
            <a href="#" style="color: #fff; text-decoration: none; font-size: 0.9rem;">View Details →</a>
          </div>
        </div>
      </div>

      <!-- Game 3 -->
      <div style="flex: 1; min-width: 250px; background: rgba(20, 20, 40, 0.7); border-radius: 15px; overflow: hidden; border: 1px solid rgba(100, 65, 165, 0.3); transition: all 0.3s ease;">
        <div style="height: 200px; overflow: hidden; position: relative;">
          <img src="https://images.unsplash.com/photo-1639762681057-408e52192e55?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2232&q=80" 
               alt="Void Hunters" 
               style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease;">
          <div style="position: absolute; bottom: 15px; left: 15px; background: rgba(0,0,0,0.7); padding: 5px 15px; border-radius: 20px; color: #bd93f9; font-weight: 700; font-size: 0.9rem;">
            VR EXCLUSIVE
          </div>
        </div>
        <div style="padding: 20px;">
          <h4 style="color: #fff; font-size: 1.3rem; margin-bottom: 10px;">Void Hunters</h4>
          <p style="color: #bbb; font-size: 0.9rem; margin-bottom: 15px; line-height: 1.5;">
            Full-body VR monster hunting with haptic feedback suits
          </p>
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <span style="color: #00f0ff; font-weight: 600;">4.8/5 ★</span>
            <a href="#" style="color: #fff; text-decoration: none; font-size: 0.9rem;">View Details →</a>
          </div>
        </div>
      </div>

      <!-- Game 4 -->
      <div style="flex: 1; min-width: 250px; background: rgba(20, 20, 40, 0.7); border-radius: 15px; overflow: hidden; border: 1px solid rgba(100, 65, 165, 0.3); transition: all 0.3s ease;">
        <div style="height: 200px; overflow: hidden; position: relative;">
          <img src="10.jpg" 
               alt="AI Revolution" 
               style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease;">
          <div style="position: absolute; bottom: 15px; left: 15px; background: rgba(0,0,0,0.7); padding: 5px 15px; border-radius: 20px; color: #32ff96; font-weight: 700; font-size: 0.9rem;">
            AI ADAPTIVE
          </div>
        </div>
        <div style="padding: 20px;">
          <h4 style="color: #fff; font-size: 1.3rem; margin-bottom: 10px;">AI Revolution</h4>
          <p style="color: #bbb; font-size: 0.9rem; margin-bottom: 15px; line-height: 1.5;">
            Strategy game where AI opponents learn from your tactics in real-time
          </p>
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <span style="color: #00f0ff; font-weight: 600;">4.6/5 ★</span>
            <a href="#" style="color: #fff; text-decoration: none; font-size: 0.9rem;">View Details →</a>
          </div>
        </div>
      </div>
    </div>

    <!-- Upcoming Events Section -->
    <div style="background: rgba(30, 30, 60, 0.5); border-radius: 15px; padding: 30px; margin-top: 50px; border: 1px solid rgba(100, 65, 165, 0.5);">
      <h3 style="color: #fff; font-size: 1.8rem; margin-bottom: 25px; text-align: center; text-transform: uppercase; letter-spacing: 1px;">
        UPCOMING TOURNAMENTS
      </h3>
      
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;">
        <!-- Event 1 -->
        <div style="background: rgba(40, 40, 80, 0.6); padding: 20px; border-radius: 10px; border-left: 4px solid #00f0ff;">
          <div style="display: flex; justify-content: space-between; margin-bottom: 15px;">
            <span style="color: #00f0ff; font-weight: 700;">JUL 15</span>
            <span style="color: #ff5e5e; font-weight: 700;">$25,000 PRIZE</span>
          </div>
          <h4 style="color: #fff; font-size: 1.2rem; margin-bottom: 10px;">Quantum Breakout Championship</h4>
          <p style="color: #bbb; font-size: 0.9rem; margin-bottom: 15px;">First major tournament for our newest FPS release</p>
          <a href="#" style="color: #00f0ff; text-decoration: none; font-size: 0.9rem; display: inline-block; margin-top: 10px;">Register Now →</a>
        </div>
        
        <!-- Event 2 -->
        <div style="background: rgba(40, 40, 80, 0.6); padding: 20px; border-radius: 10px; border-left: 4px solid #ff5e5e;">
          <div style="display: flex; justify-content: space-between; margin-bottom: 15px;">
            <span style="color: #00f0ff; font-weight: 700;">JUL 22</span>
            <span style="color: #ff5e5e; font-weight: 700;">$50,000 PRIZE</span>
          </div>
          <h4 style="color: #fff; font-size: 1.2rem; margin-bottom: 10px;">Neon Overdrive Season Finals</h4>
          <p style="color: #bbb; font-size: 0.9rem; margin-bottom: 15px;">Season 3 championship with international teams</p>
          <a href="#" style="color: #00f0ff; text-decoration: none; font-size: 0.9rem; display: inline-block; margin-top: 10px;">Register Now →</a>
        </div>
        
        <!-- Event 3 -->
        <div style="background: rgba(40, 40, 80, 0.6); padding: 20px; border-radius: 10px; border-left: 4px solid #bd93f9;">
          <div style="display: flex; justify-content: space-between; margin-bottom: 15px;">
            <span style="color: #00f0ff; font-weight: 700;">AUG 5</span>
            <span style="color: #ff5e5e; font-weight: 700;">$15,000 PRIZE</span>
          </div>
          <h4 style="color: #fff; font-size: 1.2rem; margin-bottom: 10px;">Void Hunters VR Showdown</h4>
          <p style="color: #bbb; font-size: 0.9rem; margin-bottom: 15px;">First official VR tournament with special guests</p>
          <a href="#" style="color: #00f0ff; text-decoration: none; font-size: 0.9rem; display: inline-block; margin-top: 10px;">Register Now →</a>
        </div>
      </div>
    </div>
  </div>
</section>



            
<?php include 'footer.php'?>

    <!-- Javascript -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery.easing.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/swiper-bundle.min.js"></script>
    <script src="assets/js/swiper.js"></script>

    <script src="assets/js/plugin.js"></script>
    <script src="assets/js/count-down.js"></script>
    <script src="assets/js/shortcodes.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>