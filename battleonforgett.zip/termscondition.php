<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BattleonForgett | Home - Competitive Gaming Platform</title>
    <style>
        body {
            font-family: 'Oxanium', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #0f0f1a;
            color: #e0e0e0;
        }
        .top-bar {
            background: linear-gradient(90deg, #1a1a2e 0%, #16213e 100%);
            padding: 8px 0;
            border-bottom: 1px solid #2a2a4a;
        }
        .server-status {
            display: flex;
            align-items: center;
            font-size: 14px;
        }
        .status-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            margin-right: 8px;
        }
        .online {
            background-color: #4ade80;
            box-shadow: 0 0 8px #4ade80;
        }
        .top-links {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 20px;
        }
        .download-btn {
            background: linear-gradient(90deg, #6d28d9 0%, #4c1d95 100%);
            color: white;
            padding: 6px 12px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s;
        }
        .download-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(109, 40, 217, 0.4);
        }
        .social-links {
            display: flex;
            gap: 12px;
        }
        .social-links a {
            color: #a1a1aa;
            font-size: 16px;
            transition: all 0.3s;
        }
        .social-links a:hover {
            color: #6d28d9;
            transform: translateY(-2px);
        }
        .main-header {
            padding: 20px 0;
            background-color: rgba(15, 15, 26, 0.9);
            backdrop-filter: blur(8px);
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        .logo-img {
            height: 40px;
        }
        .navbar-nav {
            gap: 20px;
        }
        .nav-link {
            color: #e0e0e0 !important;
            font-weight: 600;
            position: relative;
            padding: 8px 0 !important;
        }
        .nav-link:hover {
            color: #6d28d9 !important;
        }
        .nav-link:after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: 0;
            left: 0;
            background-color: #6d28d9;
            transition: width 0.3s;
        }
        .nav-link:hover:after {
            width: 100%;
        }
        .dropdown-menu {
            background-color: #1a1a2e;
            border: 1px solid #2a2a4a;
        }
        .dropdown-item {
            color: #e0e0e0;
        }
        .dropdown-item:hover {
            background-color: #6d28d9;
            color: white;
        }
        @media (max-width: 992px) {
            .navbar-nav {
                padding-top: 20px;
            }
            .nav-link {
                padding: 10px 0 !important;
            }
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Oxanium:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<?php include 'header.php'?>



<!-- Terms & Conditions Page: BattleonForgett -->
<section style="background: url('19.jpg') no-repeat center center/cover; padding: 80px 20px; font-family: 'Segoe UI', sans-serif; color: #fff;">

  <!-- Page Title -->
  <div style="max-width: 1000px; margin: auto; text-align: center; margin-bottom: 50px;">
    <h1 style="font-size: 42px; color: #00ffd0; margin-bottom: 10px;">📜 Terms & Conditions</h1>
    <p style="font-size: 18px; color: #d0d0d0;">Last Updated: May 21, 2025</p>
  </div>

  <!-- Main Terms Content -->
  <div style="max-width: 1000px; margin: auto; background: rgba(30,30,40,0.95); padding: 40px; border-radius: 16px; line-height: 1.8;">

    <h2 style="color: #ff4081;">1. Acceptance of Terms</h2>
    <p>By accessing or using BattleonForgett ("Website", "Game", "Platform"), you agree to comply with and be bound by these Terms & Conditions. If you do not agree, please do not use the website or our services.</p>

    <h2 style="color: #ff4081;">2. Eligibility</h2>
    <p>You must be at least 13 years old to play BattleonForgett or use any part of the website. If you are under 18, you must have parental or legal guardian consent to participate.</p>

    <h2 style="color: #ff4081;">3. Game Account</h2>
    <p>Users are responsible for maintaining the confidentiality of their account credentials. Sharing your account is prohibited. We reserve the right to suspend or terminate accounts for suspicious activity, cheating, or policy violations.</p>

    <h2 style="color: #ff4081;">4. User Conduct</h2>
    <ul style="padding-left: 20px;">
      <li>Do not harass, threaten, or abuse other players or team members.</li>
      <li>Do not exploit bugs, glitches, or use third-party tools to cheat.</li>
      <li>Do not post offensive, NSFW, or harmful content.</li>
    </ul>

    <h2 style="color: #ff4081;">5. In-Game Purchases</h2>
    <p>BattleonForgett may offer in-game purchases, including cosmetics, power-ups, and premium features. All purchases are final and non-refundable unless otherwise stated.</p>

    <h2 style="color: #ff4081;">6. Intellectual Property</h2>
    <p>All content, including graphics, text, logos, characters, and gameplay mechanics, is the intellectual property of BattleonForgett. Reproduction or distribution without permission is strictly prohibited.</p>

    <h2 style="color: #ff4081;">7. Community Participation</h2>
    <p>By joining our forums, Discord server, or other community spaces, you agree to abide by our community guidelines and moderators’ decisions. Toxic behavior may result in bans or restrictions.</p>

    <h2 style="color: #ff4081;">8. Termination</h2>
    <p>We reserve the right to suspend or terminate access to the game, account, or services at any time for conduct that violates these Terms or harms the community.</p>

    <h2 style="color: #ff4081;">9. Updates & Modifications</h2>
    <p>We may update these Terms & Conditions at any time. Continued use of the website or game after such changes constitutes acceptance of the new terms.</p>

    <h2 style="color: #ff4081;">10. Disclaimer of Warranties</h2>
    <p>The game and website are provided "as is". We make no guarantees that the game will be error-free or uninterrupted. Your use of the service is at your own risk.</p>

    <h2 style="color: #ff4081;">11. Limitation of Liability</h2>
    <p>BattleonForgett shall not be liable for any indirect, incidental, special, or consequential damages resulting from the use or inability to use the service.</p>

    <h2 style="color: #ff4081;">12. Governing Law</h2>
    <p>These Terms shall be governed by and interpreted in accordance with the laws of the state of Georgia, United States, without regard to conflict of law principles.</p>

    <h2 style="color: #ff4081;">13. Contact Information</h2>
    <p>If you have questions or concerns regarding these Terms, you may contact us at:</p>
    <p>Email: <strong>legal@battleonforgett.com</strong><br>
    Address: 123 DragonForge Road, Titan City, GA 30210</p>

  </div>

  <!-- CTA -->
  <div style="max-width: 1000px; margin: 60px auto 0; text-align: center;">
    <h2 style="color: #00ffd0; font-size: 26px;">🛡️ Stay Safe, Play Fair, Be Legendary</h2>
    <p style="color: #ccc;">We built BattleonForgett for epic warriors like you. Respect the game. Respect others. And let the adventure begin!</p>
  </div>

</section>


  <?php include 'footer.php'?>


    <a id="scroll-top"></a>

    <!-- Javascript -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery.easing.js"></script>

    <script src="assets/js/plugin.js"></script>
    <script src="assets/js/count-down.js"></script>
    <script src="assets/js/shortcodes.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>